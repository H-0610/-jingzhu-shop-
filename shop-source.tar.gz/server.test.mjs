import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { startShop,clientIp } from './server.mjs';
import { importState } from './tools/import-state.mjs';
const PASSWORD='Local-server-test-only-2026!';
const seed={settings:{shopName:'迁移测试',wechatPayCode:'wxp://local-test-only'},products:[{id:'product',name:'测试商品',enabled:true,skus:[{id:'go',name:'Go',price:1,stock:24,inventoryType:'shared',cards:[],deliveryContent:'Go固定内容'},{id:'plus',name:'Plus',price:2,stock:2,inventoryType:'cards',cards:['PLUS-ONE','PLUS-TWO']}]}],orders:[]};
async function setup(t){
 const prefix=path.join(os.tmpdir(),'jingzhu-server-test-');const directory=await fs.mkdtemp(prefix);let active;
 const restart=async filename=>{if(active)await active.close();active=await startShop({port:0,filename:filename||path.join(directory,'shop.sqlite'),origin:'https://shop.example.test',password:PASSWORD,seed});return active;};
 await restart();
 const call=async(route,{method='GET',body,token,key,headers={}}={})=>{const r=await fetch('http://127.0.0.1:'+active.port+route,{method,headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{}),...(key?{'x-order-key':key}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});const text=await r.text();let data;try{data=JSON.parse(text);}catch{data=text;}return {status:r.status,body:data,headers:r.headers};};
 const login=async()=>{const r=await call('/api/admin/login',{method:'POST',body:{password:PASSWORD}});assert.equal(r.status,200);return r.body.token;};
 t.after(async()=>{await active?.close();if(!path.resolve(directory).startsWith(path.resolve(prefix)))throw new Error('Unsafe test cleanup path');await fs.rm(directory,{recursive:true,force:true});});
 return {call,login,restart,directory,get service(){return active;}};
}
test('anonymous storefront and assets load without platform login; private files and admin data remain protected',async t=>{
 const f=await setup(t);const home=await f.call('/');assert.equal(home.status,200);assert.match(home.body,/<title>迁移测试<\/title>/);assert.match(home.body,/https:\/\/shop.example.test/);
 assert.equal((await f.call('/api/shop')).status,200);assert.equal((await f.call('/app.js')).status,200);assert.equal((await f.call('/admin')).status,200);assert.equal((await f.call('/healthz')).status,200);
 for(const url of ['/server/seed.json','/data/shop.sqlite','/schema.sql','/..%2Fserver/seed.json'])assert.equal((await f.call(url)).status,404,url);
 assert.equal((await f.call('/api/admin/data',{headers:{'oai-authenticated-user-id':'owner'}})).status,401);
 assert.match(home.headers.get('content-security-policy'),/frame-ancestors 'none'/);
});
test('orders reserve the correct SKU and survive a server restart with delivery and lookup credentials intact',async t=>{
 const f=await setup(t);let token=await f.login();
 const created=await f.call('/api/orders',{method:'POST',body:{skuId:'plus',qty:2,payMethod:'wechat',contact:'test'}});assert.equal(created.status,200);const o=created.body.order;
 let shop=(await f.call('/api/shop')).body;assert.deepEqual(shop.products[0].skus.map(s=>s.stock),[24,0]);
 await f.restart();token=await f.login();
 assert.equal((await f.call('/api/orders/'+o.orderNo,{key:o.orderKey})).body.order.delivery,'');
 assert.equal((await f.call('/api/orders/'+o.orderNo+'/paid',{method:'POST',key:o.orderKey,body:{}})).status,200);
 assert.equal((await f.call('/api/admin/orders/'+o.orderNo+'/confirm',{method:'POST',token,body:{}})).status,200);
 await f.restart();assert.equal((await f.call('/api/orders/'+o.orderNo,{key:o.orderKey})).body.order.delivery,'PLUS-ONE\nPLUS-TWO');
});
test('external CF and forwarding headers cannot override direct-client rate limiting',async t=>{
 const f=await setup(t);
 for(let n=0;n<2;n++)assert.equal((await f.call('/api/admin/login',{method:'POST',headers:{'cf-connecting-ip':'203.0.113.'+n,'x-forwarded-for':'198.51.100.'+n},body:{password:PASSWORD}})).status,200);
 const limits=f.service.db.sqlite.prepare('SELECT key,count FROM rate_limits').all();assert.equal(limits.length,1);assert.equal(limits[0].count,2);assert.ok(!limits[0].key.includes('203.0.113'));
 assert.equal(clientIp({socket:{remoteAddress:'127.0.0.1'},headers:{'x-forwarded-for':'fake, 192.0.2.9'}},1),'192.0.2.9');
});
test('complete state and image import preserves admin password, customer orders and images without overwriting a database',async t=>{
 const f=await setup(t);const token=await f.login();
 const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6VgAAAABJRU5ErkJggg==';
 const uploaded=await f.call('/api/admin/upload',{method:'POST',token,body:{dataUrl:png,target:'shareImage'}});assert.equal(uploaded.status,200);
 const order=(await f.call('/api/orders',{method:'POST',body:{skuId:'go',qty:1,payMethod:'wechat',contact:'test'}})).body.order;
 const backup={state:JSON.parse(f.service.db.sqlite.prepare('SELECT data FROM shop_state WHERE id=1').get().data),assets:f.service.db.sqlite.prepare('SELECT * FROM assets').all()};
 const filename=path.join(f.directory,'imported.sqlite');assert.deepEqual(importState(backup,filename),{products:1,orders:1,assets:1});
 assert.throws(()=>importState(backup,filename),/非空/);
 await f.restart(filename);await f.login();assert.equal((await f.call('/api/orders/'+order.orderNo,{key:order.orderKey})).status,200);assert.equal((await f.call(uploaded.body.url)).status,200);assert.equal((await f.call('/api/shop')).body.products[0].skus[0].stock,23);
});
test('startup rejects an unconfigured administrator and import rejects missing image data',async t=>{
 await assert.rejects(startShop({port:0,filename:':memory:',password:'short',seed}),/首次启动/);
 const f=await setup(t);const state=JSON.parse(f.service.db.sqlite.prepare('SELECT data FROM shop_state WHERE id=1').get().data);
 state.settings.shareImage='/api/assets/'+'a'.repeat(32);
 assert.throws(()=>importState({state,assets:[]},path.join(f.directory,'bad.sqlite')),/缺少正在使用的上传图片/);
});

test('20 distinct Go items are delivered together, with independent Plus stock and safe replenishment',async t=>{
 const f=await setup(t),token=await f.login();
 const go=Array.from({length:20},(_,i)=>`GO-${String(i+1).padStart(3,'0')} 独立交付内容`);
 const plus=Array.from({length:99},(_,i)=>`PLUS-${String(i+1).padStart(3,'0')} 独立交付内容`);
 const created=await f.call('/api/admin/products',{method:'POST',token,body:{name:'批量规格验证',skus:[{name:'Go',price:30,stock:999,inventoryType:'cards',cards:go},{name:'Plus',price:109,stock:999,inventoryType:'cards',cards:plus}]}});
 assert.equal(created.status,200);const p=created.body.product;assert.deepEqual(p.skus.map(s=>s.stock),[20,99]);
 const stocks=async()=> (await f.call('/api/shop')).body.products.find(x=>x.id===p.id).skus.map(s=>s.stock);
 const result=await f.call('/api/orders',{method:'POST',body:{skuId:p.skus[0].id,qty:20,expectedPrice:30,amount:0,payMethod:'wechat',contact:'local-bulk-test'}});
 assert.equal(result.status,200);const order=result.body.order;assert.equal(order.amount,600);assert.equal(order.delivery,'');assert.deepEqual(await stocks(),[0,99]);
 assert.equal((await f.call('/api/admin/products',{method:'POST',token,body:{...p,expectedRevision:p.revision}})).status,409);
 assert.equal((await f.call('/api/orders',{method:'POST',body:{skuId:p.skus[0].id,qty:1,payMethod:'wechat',contact:'local-bulk-test'}})).status,409);
 await f.call('/api/orders/'+order.orderNo+'/paid',{method:'POST',key:order.orderKey,body:{}});
 for(let i=0;i<2;i++)assert.equal((await f.call('/api/admin/orders/'+order.orderNo+'/confirm',{method:'POST',token,body:{}})).status,200);
 const delivered=(await f.call('/api/orders/'+order.orderNo,{key:order.orderKey})).body.order.delivery.split('\n');
 assert.deepEqual(delivered,go);assert.equal(new Set(delivered).size,20);assert.ok(delivered.every(x=>!plus.includes(x)));assert.deepEqual(await stocks(),[0,99]);
 const fresh=(await f.call('/api/admin/data',{token})).body.products.find(x=>x.id===p.id);
 const save=cards=>f.call('/api/admin/products',{method:'POST',token,body:{...fresh,expectedRevision:fresh.revision,skus:[{...fresh.skus[0],cards},fresh.skus[1]]}});
 assert.equal((await save(['DUP','DUP'])).status,400);assert.equal((await save([go[0]])).status,409);
 assert.equal((await save(['GO-NEW-1','GO-NEW-2'])).status,200);assert.deepEqual(await stocks(),[2,99]);
 const held=(await f.call('/api/orders',{method:'POST',body:{skuId:p.skus[0].id,qty:2,payMethod:'wechat',contact:'local-bulk-test'}})).body.order;
 for(let i=0;i<2;i++)assert.equal((await f.call('/api/admin/orders/'+held.orderNo+'/cancel',{method:'POST',token,body:{}})).status,200);
 assert.deepEqual(await stocks(),[2,99]);
});
