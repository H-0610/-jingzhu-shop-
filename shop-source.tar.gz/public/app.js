// 自助下单小铺。查询码只保存在本设备与客户保存的订单凭证中。
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const yuan = n => '¥' + Number(n).toFixed(2);
const STATUS = { pending: '待付款', paid: '待商家核对', completed: '已完成', closed: '已关闭' };
const PAY = { wechat: '微信支付', alipay: '支付宝' };
let shop = null, viewMode = localStorage.getItem('viewMode') || 'card', lastOrders = [], payTimer = null, currentModalClose = null, checkoutChanged = null, liveSync = null;
function myOrders() { try {
    return JSON.parse(localStorage.getItem('myOrdersV2') || '[]').filter(o => o && typeof o.no === 'string' && typeof o.key === 'string');
}
catch {
    return [];
} }
const savedKey = no => myOrders().find(o => o.no === no)?.key || '';
function saveMyOrder(no, key) { if (!no || !key)
    return; const list = myOrders().filter(o => o.no !== no); list.unshift({ no, key }); localStorage.setItem('myOrdersV2', JSON.stringify(list.slice(0, 20))); }
async function api(url, opts = {}) {
    const target = new URL(url, location.origin), no = target.pathname.match(/^\/api\/orders\/(\d+)(?:\/paid)?$/)?.[1] || target.searchParams.get('kw');
    const key = opts.orderKey || savedKey(no);
    const res = await fetch(url, { method: opts.method || 'GET', headers: { 'Content-Type': 'application/json', ...(key ? { 'X-Order-Key': key } : {}), ...opts.headers }, body: opts.body ? JSON.stringify(opts.body) : undefined, cache: 'no-store', signal: opts.signal });
    const data = await res.json().catch(() => ({}));
    if (!res.ok)
        throw new Error(data.error || '请求失败');
    return data;
}
function toast(msg) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 2600); }
async function copyText(value, message = '已复制') {
    try {
        await navigator.clipboard.writeText(value);
    }
    catch {
        const el = document.createElement('textarea');
        el.value = value;
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.select();
        const ok = document.execCommand('copy');
        el.remove();
        if (!ok)
            throw new Error('无法自动复制，请手动保存');
    }
    toast(message);
}
const credentialText = o => `订单号：${o.orderNo}\n查询码：${o.orderKey || savedKey(o.orderNo)}\n查询入口：${location.origin}/#query\n请妥善保管查询码，不要公开分享。`;
const credentialHtml = o => `<div class="order-credential"><strong>请保存订单凭证</strong><div>订单号 <code>${esc(o.orderNo)}</code></div><div>查询码 <code>${esc(o.orderKey || savedKey(o.orderNo))}</code></div><button class="btn btn-sm" data-copy-order="${esc(o.orderNo)}">复制订单号和查询码</button><p>查询码可查看订单及交付内容，请勿发给他人。</p></div>`;
const iconHtml = icon => /^(\/|https?:)/.test(icon || '') ? `<img src="${esc(icon)}" alt="" />` : esc(icon || '📦');
function openModal(title, bodyHtml, { wide = false, onClose } = {}) {
    if (currentModalClose)
        currentModalClose();
    const root = $('#modalRoot');
    root.innerHTML = `<div class="mask"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-head"><span>${esc(title)}</span><button class="modal-close" aria-label="关闭">×</button></div><div class="modal-body">${bodyHtml}</div></div></div>`;
    const previousFocus = document.activeElement;
    const close = () => { root.innerHTML = ''; if (currentModalClose === close)
        currentModalClose = null; document.removeEventListener('keydown', onKey); onClose?.(); previousFocus?.focus?.(); };
    const onKey = e => { if (e.key === 'Escape')
        close(); if (e.key === 'Tab') {
        const focusable = $$('button:not(:disabled),input,textarea,a[href]', root);
        const first = focusable[0], last = focusable.at(-1);
        if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last?.focus();
        }
        else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first?.focus();
        }
    } };
    $('.modal-close', root).onclick = close;
    $('.mask', root).onclick = e => { if (e.target.classList.contains('mask'))
        close(); };
    currentModalClose = close;
    document.addEventListener('keydown', onKey);
    $('.modal-close', root).focus();
    return { el: $('.modal-body', root), close };
}
function applyShop(next) {
    const previous = shop;
    shop = next;
    document.title = shop.shopName;
    $('#shopName').textContent = shop.shopName;
    $('#shopSub').textContent = shop.shopSubtitle || '';
    $('#sideContact').textContent = shop.contact || '';
    $('#notice').textContent = shop.notice || '';
    $('#notice').classList.toggle('hidden', !shop.notice);
    const description = document.querySelector('meta[name="description"]');
    if (description) description.content = shop.shareDesc || '';
    if (!previous || JSON.stringify(previous.products) !== JSON.stringify(shop.products)) renderGrid();
    checkoutChanged?.();
    const contactBody = $('#liveContact');
    if (contactBody) contactBody.textContent = shop.contact || '商家尚未设置客服联系方式，请稍后再试。';
}
function syncStatus({state, lastSyncedAt}) {
    const el = $('#syncStatus');
    if (!el) return;
    state = state === 'synced' || (state === 'syncing' && lastSyncedAt) ? 'live' : state;
    el.dataset.state = state;
    const messages = {live:'自动同步中', syncing:'正在同步…', offline:'网络已断开，恢复后自动同步', error:'同步暂时中断，正在重试', paused:'返回页面后自动同步'};
    const message = messages[state] || '正在连接…';
    if (el.textContent !== message) el.textContent = message;
    el.title = lastSyncedAt ? '最近同步：' + new Date(lastSyncedAt).toLocaleTimeString() : '后台保存后自动更新，通常约2秒';
}
async function loadShop() {
    return liveSync.refresh();
}
function renderGrid() {
    if (!shop)
        return;
    const kw = $('#search').value.trim().toLowerCase(), grid = $('#grid');
    const quantities = new Map($$('[data-qty]', grid).map(input => [input.dataset.qty, input.value]));
    const focusedSku = document.activeElement?.dataset?.qty;
    grid.classList.toggle('list', viewMode === 'list');
    $$('.seg button').forEach(b => b.classList.toggle('on', b.dataset.mode === viewMode));
    const list = shop.products.map(p => { if (!kw || p.name.toLowerCase().includes(kw))
        return p; const skus = p.skus.filter(s => s.name.toLowerCase().includes(kw)); return skus.length ? { ...p, skus } : null; }).filter(Boolean);
    $('#meta').innerHTML = `<b>${list.length}</b> 个商品 · <b>${list.reduce((s, p) => s + p.skus.length, 0)}</b> 个规格`;
    if (!list.length) {
        grid.innerHTML = kw ? '<div class="shop-empty"><div class="empty-icon">⌕</div><h2>没有找到相关商品</h2><p>换个关键词再试试，或联系客服咨询。</p></div>' : '<div class="shop-empty"><div class="empty-icon">🛍</div><span class="empty-label">SELF-SERVICE SHOP</span><h2>好物正在准备中</h2><p>商家正在整理商品，稍后再来看看。<br/>如有采购需求，可以先联系客服。</p><button class="btn btn-primary" data-contact>联系客服</button></div>';
        return;
    }
    grid.innerHTML = list.map(p => `<div class="pcard"><div class="pcard-head"><div class="picon">${iconHtml(p.icon)}</div><div class="pname">${esc(p.name)}</div>${p.tag ? `<span class="ptag">${esc(p.tag)}</span>` : ''}</div><div class="sku-wrap">${p.skus.map(s => `<div class="sku"><div class="sku-top"><span class="pill">${esc(s.name)}</span><span class="stock">可售 ${s.stock}</span></div><div class="sku-bottom"><div class="sku-pricing" aria-live="polite"><div class="price" data-total>${yuan(s.price)}</div><div class="quantity-summary" data-quantity-summary hidden></div><div class="unit-price" data-unit-price hidden>单价 ${yuan(s.price)}</div></div><input class="qty" aria-label="${esc(s.name)}购买数量" type="number" min="1" step="1" max="${Math.max(1, Math.min(999, s.stock))}" value="1" data-qty="${esc(s.id)}" ${s.stock ? '' : 'disabled'} /><button class="btn btn-primary btn-sm" data-buy="${esc(s.id)}" ${s.stock ? '' : 'disabled'}>${s.stock ? '购买' : '售罄'}</button></div><div class="quantity-error" data-quantity-error hidden></div></div>`).join('')}</div></div>`).join('');
    $$('[data-qty]', grid).forEach(input => {
        if (quantities.has(input.dataset.qty)) {
            const value = quantities.get(input.dataset.qty);
            input.value = /^\d+$/.test(value) && Number(value) >= 1 ? Math.min(Number(input.max), Number(value)) : value;
        }
        updateSkuTotal(input);
        if (input.dataset.qty === focusedSku && !input.disabled) input.focus({preventScroll:true});
    });
}
function updateSkuTotal(input) {
    const found = findSku(input.dataset.qty);
    if (!found) return null;
    const row = input.closest('.sku'), sku = found.s;
    const qty = Number(input.value), max = Math.min(999, sku.stock);
    const valid = /^\d+$/.test(input.value) && Number.isSafeInteger(qty) && qty >= 1 && qty <= max;
    const multiple = valid && qty > 1;
    row.classList.toggle('is-multiple', multiple);
    $('[data-total]', row).textContent = valid ? yuan(Math.round(sku.price * 100) * qty / 100) : (sku.stock ? '—' : yuan(sku.price));
    const summary = $('[data-quantity-summary]', row), unit = $('[data-unit-price]', row), error = $('[data-quantity-error]', row);
    summary.hidden = !multiple; summary.textContent = multiple ? `${qty} 件合计` : '';
    unit.hidden = !multiple && valid; unit.textContent = `单价 ${yuan(sku.price)}`;
    error.hidden = valid || !sku.stock;
    error.textContent = !valid && sku.stock ? `请输入 1–${max} 的整数数量` : '';
    input.setAttribute('aria-invalid', String(!valid && !!sku.stock));
    $('[data-buy]', row).disabled = !valid;
    return valid ? qty : null;
}
function findSku(id) { for (const p of shop.products) {
    const s = p.skus.find(x => x.id === id);
    if (s)
        return { p, s };
} return null; }
function openCheckout(skuId) {
    const initial = findSku(skuId);
    if (!initial) return;
    if (!shop.pay.alipay && !shop.pay.wechat) { toast('店铺暂未开通收款，请联系客服'); return; }
    const qty = updateSkuTotal($('[data-qty="' + skuId + '"]'));
    if (qty === null) { toast('请填写正确的采购数量'); return; }
    if (qty > initial.s.stock) { toast('库存不足，请重新选择数量'); return; }
    let payMethod = shop.pay.alipay ? 'alipay' : 'wechat', submitting = false;
    const m = openModal('确认订单', `
      <div class="kv"><span>商品</span><span id="coProductName"></span></div>
      <div class="kv"><span>规格</span><span id="coSkuName"></span></div>
      <div class="kv"><span>单价 / 数量</span><span id="coUnitPrice"></span></div>
      <div class="kv"><span>应付金额</span><span class="total" id="coAmount"></span></div>
      <p class="payment-note hidden" id="coSyncNotice" role="status"></p>
      <div class="field"><label for="coContact">联系方式 *（手机号 / 微信号，用于订单联系和售后）</label><input class="input" id="coContact" maxlength="100" value="${esc(localStorage.getItem('lastContact') || '')}" /></div>
      <div class="field"><label for="coRemark">备注（选填）</label><textarea class="textarea" id="coRemark" maxlength="300" placeholder="如有特殊要求请填写"></textarea></div>
      <div class="field"><label>支付方式</label><div class="paytabs"><button class="paytab alipay" data-pay="alipay"><span class="pay-ic ali">支</span>支付宝</button><button class="paytab wechat" data-pay="wechat"><span class="pay-ic wx">微</span>微信</button></div></div>
      <p class="tip">下单后会生成订单号和专属查询码，请保存后再付款。</p>
      <div class="field"><button class="btn btn-primary btn-block" id="coSubmit">提交订单</button></div>`,
      {onClose: () => { if (checkoutChanged === updateCheckout) checkoutChanged = null; }});
    const fingerprint = () => {
        const f = findSku(skuId);
        return JSON.stringify(f ? {name:f.p.name, sku:f.s.name, price:f.s.price, available:f.s.stock >= qty, payMethod, pay:!!shop.pay[payMethod]} : null);
    };
    let reviewed = fingerprint();
    const tell = text => { const note = $('#coSyncNotice', m.el); note.textContent = text; note.classList.toggle('hidden', !text); };
    function updateCheckout() {
        if (!m.el.isConnected) return;
        const f = findSku(skuId), button = $('#coSubmit', m.el);
        if (!shop.pay[payMethod]) payMethod = shop.pay.alipay ? 'alipay' : 'wechat';
        $$('.paytab', m.el).forEach(b => {b.disabled = submitting || !shop.pay[b.dataset.pay]; b.classList.toggle('on', b.dataset.pay === payMethod && !!shop.pay[payMethod]);});
        const valid = !!f && f.s.stock >= qty && !!shop.pay[payMethod];
        button.disabled = submitting || !valid;
        if (!f) { tell('该商品已下架或删除，请关闭弹窗重新选购。'); button.textContent='商品已下架'; return; }
        $('#coProductName', m.el).textContent = f.p.name;
        $('#coSkuName', m.el).textContent = f.s.name;
        $('#coUnitPrice', m.el).textContent = yuan(f.s.price) + ' × ' + qty;
        $('#coAmount', m.el).textContent = yuan(Math.round(f.s.price * 100) * qty / 100);
        if (f.s.stock < qty) { tell('库存已更新，当前仅剩 ' + f.s.stock + ' 件，请重新选择数量。'); button.textContent='库存不足'; }
        else if (!shop.pay[payMethod]) { tell('收款方式已更新，请稍后重试或联系客服。'); button.textContent='暂不可付款'; }
        else if (fingerprint() !== reviewed) { tell('商品信息已更新，请核对最新名称、价格和支付方式后再下单。'); button.textContent='确认最新信息并下单'; }
        else { tell(''); button.textContent = submitting ? '正在提交…' : '提交订单'; }
    }
    checkoutChanged = updateCheckout;
    $$('.paytab', m.el).forEach(b => b.onclick = () => { payMethod = b.dataset.pay; reviewed = fingerprint(); updateCheckout(); });
    updateCheckout();
    $('#coSubmit', m.el).onclick = async () => {
        const contact = $('#coContact', m.el).value.trim();
        if (!contact) { toast('请填写联系方式'); return; }
        const accepted = fingerprint();
        submitting = true; updateCheckout();
        try {
            await loadShop();
            if (!m.el.isConnected) return;
            const f = findSku(skuId);
            if (!f || f.s.stock < qty || !shop.pay[payMethod]) { updateCheckout(); return; }
            if (fingerprint() !== accepted) { tell('商品信息刚刚发生变动，请核对后再点击提交。'); toast('商品信息已更新，请重新确认'); return; }
            const {order} = await api('/api/orders', {method:'POST', body:{skuId,qty,payMethod,expectedPrice:f.s.price,contact,remark:$('#coRemark',m.el).value}});
            localStorage.setItem('lastContact',contact); saveMyOrder(order.orderNo,order.orderKey); showPay(order); loadShop().catch(()=>{});
        } catch (error) { toast(error.message); loadShop().catch(()=>{}); }
        finally { submitting=false; if (m.el.isConnected) updateCheckout(); }
    };
}
// 重绘保留原支付地址；二维码内并未绑定订单金额。
function renderPayQr(code, method, amount) { const qr = qrcode(0, 'M'); qr.addData(code); qr.make(); const n = qr.getModuleCount(), cell = Math.max(4, Math.floor(260 / n)), size = n * cell, pad = 24, W = size + pad * 2, head = 56, foot = 44, c = document.createElement('canvas'); c.width = W; c.height = head + size + pad * 2 + foot; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = method === 'wechat' ? '#07c160' : '#1677ff'; g.fillRect(0, 0, W, head); g.fillStyle = '#fff'; g.font = 'bold 20px "Microsoft YaHei",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(method === 'wechat' ? '微信扫码支付' : '支付宝扫码支付', W / 2, head / 2); g.fillStyle = '#111'; for (let r = 0; r < n; r++)
    for (let col = 0; col < n; col++)
        if (qr.isDark(r, col))
            g.fillRect(pad + col * cell, head + pad + r * cell, cell, cell); g.fillStyle = '#c2410c'; g.font = 'bold 22px "Microsoft YaHei",sans-serif'; g.fillText(yuan(amount), W / 2, head + size + pad * 2 + foot / 2 - 6); return c.toDataURL('image/png'); }
function showPay(order) {
    if (order.status === 'paid') return showWaiting(order);
    if (order.status === 'completed') return showDone(order);
    const pay = order.payment;
    if (!pay) {
        toast('该支付方式暂不可用，请联系客服');
        return;
    }
    saveMyOrder(order.orderNo, order.orderKey);
    const img = pay.code ? renderPayQr(pay.code, order.payMethod, order.amount) : pay.img, isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent), canOpenAlipay = order.payMethod === 'alipay' && pay.code && /^https:\/\/qr\.alipay\.com\//.test(pay.code) && isMobile;
    const m = openModal('扫码付款', `<div style="text-align:center"><div class="total" style="font-size:30px">${yuan(order.amount)}</div><div class="tip">${PAY[order.payMethod]} · 请按订单金额支付</div></div>${credentialHtml(order)}<div class="qrbox" style="margin:12px 0 6px"><img src="${esc(img)}" alt="${PAY[order.payMethod]}收款二维码" id="payImg" /></div><div class="tip" style="text-align:center">付款时限 <b id="payLeft">--:--</b></div><div style="display:flex;gap:8px;justify-content:center;margin:10px 0"><button class="btn" id="btnSaveQr">保存收款码</button>${canOpenAlipay ? `<a class="btn btn-primary" href="${esc(pay.code)}">打开支付宝付款</a>` : ''}</div><div class="tip" style="text-align:center">${isMobile ? `可保存二维码，到${PAY[order.payMethod]}「扫一扫 → 相册」识别` : `请用手机${PAY[order.payMethod]}扫一扫`}<br/>付款备注建议填写订单号后 6 位：<b>${esc(order.orderNo.slice(-6))}</b></div><div class="payment-note">收款方以微信 / 支付宝确认页为准。此为静态收款码，请手动输入准确金额；图片上的金额仅作提示。商家会人工核对到账。</div><div class="wait-bar" id="waitBar">${order.status === 'paid' ? '⏳ 已提交付款信息，等待商家核对。请勿重复付款。' : 'ⓘ 付款后请提交付款信息，商家核对到账后处理订单。'}</div><div class="cs-bar"><span>付款遇到问题？</span><button class="btn btn-sm" id="btnPayCs">联系客服</button></div><div class="field"><label for="payNote">付款信息（昵称 / 交易单号后 4 位，方便商家核对）</label><input class="input" id="payNote" maxlength="200" /></div><div class="field" style="display:flex;gap:10px"><button class="btn" id="btnPayClose" style="flex:1;justify-content:center">关闭</button><button class="btn btn-primary" id="btnPaid" style="flex:2;justify-content:center" ${order.status === 'paid' ? 'disabled' : ''}>${order.status === 'paid' ? '已提交，等待核对' : '我已付款，提交核对'}</button></div>`, { onClose: () => clearInterval(payTimer) });
    const expireAt = new Date(order.expireAt || new Date(order.createdAt).getTime() + 30 * 60000).getTime();
    let tick = 0;
    const update = async () => { if (!m.el.isConnected)
        return clearInterval(payTimer); const left = Math.max(0, expireAt - Date.now()), el = $('#payLeft', m.el); el.textContent = order.status === 'paid' ? '等待商家核对' : `${String(Math.floor(left / 60000)).padStart(2, '0')}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}`; if (++tick % 5 === 0) {
        try {
            const { order: o } = await api('/api/orders/' + order.orderNo);
            if (!m.el.isConnected)
                return;
            if (o.status === 'completed') {
                showDone(o);
                loadShop().catch(() => { });
                return;
            }
            if (o.status === 'closed') {
                m.close();
                toast('订单已关闭：' + (o.closeReason || ''));
                loadShop().catch(() => { });
                return;
            }
            if (o.status === 'paid') {
                showWaiting(o);
                return;
            }
        }
        catch { }
    } if (!left && order.status === 'pending') {
        $('#waitBar', m.el).textContent = '订单已超时，请勿继续付款，请重新下单。';
        $('#btnPaid', m.el).disabled = true;
    } };
    update();
    payTimer = setInterval(update, 1000);
    $('#btnSaveQr', m.el).onclick = () => { const a = document.createElement('a'); a.href = img; a.download = `收款码-${order.orderNo}.png`; a.click(); if (isMobile)
        toast('如未自动保存，请长按二维码保存图片'); };
    $('#btnPayCs', m.el).onclick = () => alert(shop?.contact || '暂未设置客服');
    $('#btnPayClose', m.el).onclick = m.close;
    $('#btnPaid', m.el).onclick = async (e) => { e.target.disabled = true; try {
        const {order: submitted} = await api(`/api/orders/${order.orderNo}/paid`, { method: 'POST', body: { payNote: $('#payNote', m.el).value } });
        if (m.el.isConnected) showWaiting(submitted);
        order.status = 'paid';
        if (!m.el.isConnected)
            return;
        $('#waitBar', m.el).textContent = '⏳ 已提交付款信息，等待商家核对实际到账。请勿重复付款。';
        e.target.textContent = '已提交，等待核对';
        update();
    }
    catch (err) {
        toast(err.message);
        if (m.el.isConnected)
            e.target.disabled = false;
    } };
}
function deliveryHtml(o) {
    return o.delivery ? `<div class="delivery-head"><b>${esc(o.skuName)} · 发货内容</b><button class="btn btn-sm" data-copy-delivery="${esc(o.orderNo)}">复制内容</button></div><div class="delivery">${esc(o.delivery)}</div>` : '';
}
function rememberOrder(o) {
    saveMyOrder(o.orderNo, o.orderKey);
    const index = lastOrders.findIndex(item => item.orderNo === o.orderNo);
    if (index < 0) lastOrders.unshift(o); else lastOrders[index] = o;
}
function showWaiting(o) {
    rememberOrder(o);
    let watcher;
    const m = openModal('等待核对到账', `<div class="result-icon">⏳</div><p style="text-align:center;line-height:1.8"><b>${esc(o.productName)} / ${esc(o.skuName)} × ${o.qty}</b><br/>已提交付款信息，请勿重复付款。<br/>商家确认收款后，此页面会自动显示对应内容。</p><div class="tip" data-order-status role="status">正在连接订单…</div>${credentialHtml(o)}<button class="btn btn-block" id="waitQuery">查看订单</button>`, {onClose:()=>watcher?.stop()});
    watcher = ShopLiveSync.create({
        intervalMs:3000,
        load:({signal})=>api('/api/orders/'+o.orderNo,{signal,orderKey:o.orderKey}),
        apply:({order})=>{
            if(!m.el.isConnected) return;
            if(order.status==='completed') {showDone(order);loadShop().catch(()=>{});}
            else if(order.status==='closed') {m.close();toast('订单已关闭：'+order.closeReason);loadShop().catch(()=>{});}
        },
        onStatus:({state})=>{const el=$('[data-order-status]',m.el);if(el)el.textContent=state==='error'?'订单同步暂时中断，正在重试':state==='offline'?'网络已断开，恢复后自动查询':'订单自动更新中，可保留此页等待交付';}
    });
    watcher.start();
    $('#waitQuery',m.el).onclick=()=>{m.close();$('#queryKw').value=o.orderNo;$('#queryKey').value=o.orderKey||savedKey(o.orderNo);location.hash='#query';doQuery();};
}
function showDone(o) {
    rememberOrder(o);
    const m=openModal('订单已完成',`<div class="result-icon">✅</div><p style="text-align:center;line-height:1.8">商家已确认收款，订单已完成。<br/><b>${esc(o.productName)} / ${esc(o.skuName)} × ${o.qty}</b></p>${deliveryHtml(o)}${credentialHtml(o)}<div class="field"><button class="btn btn-primary btn-block" id="btnGoQuery">查看订单</button></div>`);
    $('#btnGoQuery',m.el).onclick=()=>{m.close();$('#queryKw').value=o.orderNo;$('#queryKey').value=o.orderKey||savedKey(o.orderNo);location.hash='#query';doQuery();};
}
function orderCard(o) { return `<div class="ocard" data-order-card="${esc(o.orderNo)}"><div class="ocard-head"><span>订单号 ${esc(o.orderNo)} · ${new Date(o.createdAt).toLocaleString()}</span><span class="status st-${o.status}">${STATUS[o.status] || o.status}</span></div><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><span><b>${esc(o.productName)}</b> · <span class="pill">${esc(o.skuName)}</span> × ${o.qty}</span><span class="price" style="flex:none">${yuan(o.amount)}</span></div>${o.status === 'pending' ? `<div style="margin-top:10px"><button class="btn btn-primary btn-sm" data-repay="${esc(o.orderNo)}">继续付款</button></div>` : ''}${o.status === 'paid' ? '<p class="tip">等待商家核对到账。确认后此处自动显示对应规格的内容，请勿重复付款。</p>' : ''}${o.closeReason ? `<div class="tip">关闭原因：${esc(o.closeReason)}</div>` : ''}${deliveryHtml(o)}<div style="margin-top:10px"><button class="btn btn-sm" data-copy-order="${esc(o.orderNo)}">复制订单凭证</button></div></div>`; }
let queryGeneration=0, queryRefreshRunning=false, queryCursor=0;
async function refreshVisibleOrders() {
    if(location.hash!=='#query'||document.hidden||navigator.onLine===false||queryRefreshRunning) return;
    const active=lastOrders.filter(o=>['pending','paid'].includes(o.status)&&document.querySelector('[data-order-card="'+o.orderNo+'"]'));
    if(!active.length) return;
    const generation=queryGeneration;
    const selected=Array.from({length:Math.min(3,active.length)},(_,i)=>active[(queryCursor+i)%active.length]);
    queryCursor=(queryCursor+selected.length)%active.length;
    queryRefreshRunning=true;
    try {
        await Promise.all(selected.map(async previous=>{
            try {
                const {order}=await api('/api/orders/'+previous.orderNo,{orderKey:previous.orderKey,signal:AbortSignal.timeout(10000)});
                if(queryGeneration!==generation||location.hash!=='#query')return;
                const card=document.querySelector('[data-order-card="'+order.orderNo+'"]');
                if(card&&JSON.stringify(order)!==JSON.stringify(previous)){rememberOrder(order);card.outerHTML=orderCard(order);}
            }catch{}
        }));
    }finally{queryRefreshRunning=false;}
}
setInterval(refreshVisibleOrders,5000);
window.addEventListener('online',refreshVisibleOrders);
window.addEventListener('focus',refreshVisibleOrders);
document.addEventListener('visibilitychange',refreshVisibleOrders);
async function doQuery() {
    const generation=++queryGeneration;
    const kw = $('#queryKw').value.trim(), box = $('#queryResult');
    $('#btnQuery').disabled = true;
    try {
        if (kw) {
            const key = $('#queryKey').value.trim() || savedKey(kw);
            if (!key) {
                toast('请输入订单查询码');
                return;
            }
            const { orders } = await api('/api/orders/query?kw=' + encodeURIComponent(kw), { orderKey: key });
            if(generation!==queryGeneration)return;
            if (orders.length)
                saveMyOrder(kw, key);
            lastOrders = orders;
        }
        else {
            const results = await Promise.all(myOrders().map(({ no, key }) => api('/api/orders/' + encodeURIComponent(no), { orderKey: key }).then(r => r.order).catch(() => null)));
            if(generation!==queryGeneration)return;
            lastOrders = results.filter(Boolean);
        }
        box.innerHTML = lastOrders.length ? (kw ? '' : '<div class="tip" style="margin-bottom:10px">本设备最近的订单：</div>') + lastOrders.map(orderCard).join('') : `<div class="empty">${kw ? '没有找到相关订单，请核对订单号与查询码' : '本设备暂无订单记录，可输入订单号和查询码查看'}</div>`;
    }
    catch (err) {
        box.innerHTML = '<div class="empty">查询未完成，请核对订单凭证后重试。</div>';
        toast(err.message);
    }
    finally {
        $('#btnQuery').disabled = false;
    }
}
function route() { const view = location.hash === '#query' ? 'query' : 'shop'; $('#view-shop').classList.toggle('hidden', view !== 'shop'); $('#view-query').classList.toggle('hidden', view !== 'query'); $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.view === view)); if (view === 'query' && !$('#queryKw').value)
    doQuery(); }
document.addEventListener('click', e => { const delivery=e.target.closest('[data-copy-delivery]'); if(delivery){const o=lastOrders.find(item=>item.orderNo===delivery.dataset.copyDelivery);if(o?.delivery)copyText(o.delivery,'发货内容已复制').catch(error=>toast(error.message));return;} const copy = e.target.closest('[data-copy-order]'); if (copy) {
    const no = copy.dataset.copyOrder, o = lastOrders.find(x => x.orderNo === no) || { orderNo: no, orderKey: savedKey(no) };
    copyText(credentialText(o), '订单凭证已复制，请妥善保存').catch(er => toast(er.message));
    return;
} if (e.target.closest('[data-contact]')) {
    $('#floatCs').click();
    return;
} const buy = e.target.closest('[data-buy]'); if (buy)
    return openCheckout(buy.dataset.buy); const repay = e.target.closest('[data-repay]'); if (repay) {
    const o = lastOrders.find(x => x.orderNo === repay.dataset.repay);
    if (o)
        showPay(o);
    return;
} const seg = e.target.closest('.seg button'); if (seg) {
    viewMode = seg.dataset.mode;
    localStorage.setItem('viewMode', viewMode);
    renderGrid();
} });
$('#search').addEventListener('input', renderGrid);
$('#grid').addEventListener('input', e => { if (e.target.matches('[data-qty]')) updateSkuTotal(e.target); });
$('#btnRefresh').onclick = () => loadShop().then(() => toast('已刷新')).catch(e => toast(e.message));
$('#btnQuery').onclick = doQuery;
for (const id of ['#queryKw', '#queryKey'])
    $(id).addEventListener('keydown', e => { if (e.key === 'Enter')
        doQuery(); });
$('#floatCs').onclick = () => openModal('联系客服', `<div id="liveContact" style="white-space:pre-wrap;line-height:1.8">${esc(shop?.contact || '商家尚未设置客服联系方式，请稍后再试。')}</div>`);
$('#btnShare').onclick = async () => { const value = { title: shop?.shopName || '景筑小铺', text: shop?.shareDesc || '自助选购，扫码下单', url: location.origin + '/' }; try {
    if (navigator.share)
        await navigator.share(value);
    else
        await copyText(value.url, '小铺链接已复制');
}
catch (e) {
    if (e.name !== 'AbortError')
        copyText(value.url, '小铺链接已复制').catch(er => toast(er.message));
} };
window.addEventListener('hashchange', route);
liveSync = ShopLiveSync.create({
    load: ({signal}) => api('/api/shop', {signal}),
    apply: applyShop,
    onStatus: syncStatus
});
liveSync.start();
route();
