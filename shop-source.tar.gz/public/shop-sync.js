(function (root) {
  'use strict';
  function create(options) {
    if (!options || typeof options.load !== 'function' || typeof options.apply !== 'function') throw new TypeError('load and apply are required');
    const environment = options.environment || root;
    const win = environment.window || environment;
    const doc = environment.document || win.document;
    const nav = environment.navigator || win.navigator || {};
    const later = (environment.setTimeout || root.setTimeout).bind(environment);
    const cancelTimer = (environment.clearTimeout || root.clearTimeout).bind(environment);
    const Controller = environment.AbortController || root.AbortController;
    const Channel = environment.BroadcastChannel || win.BroadcastChannel;
    const now = environment.now || (() => Date.now());
    const interval = Math.max(1, options.intervalMs || 2000);
    const timeout = Math.max(1, options.timeoutMs || 10000);
    let active = false, pagePaused = false, timer = null, flight = null, dirty = false;
    let epoch = 0, failures = 0, lastSyncedAt = null, snapshot, signature, hasSnapshot = false, channel = null;
    let waiters = [];
    const listeners = [];
    const online = () => nav.onLine !== false;
    const visible = () => !doc || (doc.visibilityState !== 'hidden' && !doc.hidden);
    const available = () => active && !pagePaused && online() && visible();
    function status(state, error) {
      try { options.onStatus?.({ state, lastSyncedAt, ...(error ? { error } : {}) }); } catch (_) {}
    }
    function clearPoll() { if (timer !== null) cancelTimer(timer); timer = null; }
    function settle(error, value) {
      const pending = waiters; waiters = [];
      for (const waiter of pending) error ? waiter.reject(error) : waiter.resolve(value);
    }
    function pauseStatus() { status(!online() ? 'offline' : 'paused'); }
    function schedule() {
      clearPoll();
      if (!active) return;
      if (!available()) { pauseStatus(); return; }
      const delay = failures ? Math.min(30000, interval * Math.pow(2, failures - 1)) : interval;
      timer = later(() => { timer = null; invalidate(); }, delay);
    }
    function invalidate() {
      if (!active) return;
      epoch += 1; dirty = true; clearPoll();
      if (available()) pump(); else pauseStatus();
    }
    function pump() {
      if (!active || flight || !dirty || !available()) return;
      dirty = false;
      const run = { epoch, controller: new Controller(), timeout: null, cancel: null };
      flight = run;
      const cancellation = new Promise((_, reject) => { run.cancel = reject; });
      run.timeout = later(() => {
        const error = new Error('同步请求超时，请稍后重试'); error.name = 'TimeoutError';
        run.controller.abort(error); run.cancel(error);
      }, timeout);
      status('syncing');
      (async () => {
        try {
          const next = await Promise.race([Promise.resolve().then(() => options.load({ signal: run.controller.signal })), cancellation]);
          if (!active || flight !== run || run.epoch !== epoch || dirty) return;
          const nextSignature = JSON.stringify(next);
          if (!hasSnapshot || nextSignature !== signature) {
            options.apply(next);
            signature = nextSignature; hasSnapshot = true;
          }
          snapshot = next; lastSyncedAt = now(); failures = 0;
          status('synced');
          if (run.epoch === epoch && !dirty) settle(null, snapshot);
        } catch (error) {
          if (!active || flight !== run || run.epoch !== epoch || dirty) return;
          failures += 1;
          status('error', error);
          settle(error);
        } finally {
          if (run.timeout !== null) cancelTimer(run.timeout);
          if (flight !== run) return;
          flight = null;
          if (!active) return;
          if (dirty && available()) pump(); else schedule();
        }
      })();
    }
    function listen(target, type, handler) {
      if (!target?.addEventListener) return;
      target.addEventListener(type, handler); listeners.push(() => target.removeEventListener(type, handler));
    }
    function abortFlight(message) {
      if (!flight) return;
      const error = new Error(message); error.name = 'AbortError';
      if (flight.timeout !== null) cancelTimer(flight.timeout); flight.timeout = null;
      flight.controller.abort(error); flight.cancel(error);
    }
    function start() {
      if (active) return;
      active = true; pagePaused = false;
      listen(doc, 'visibilitychange', () => { if (visible()) invalidate(); else { clearPoll(); pauseStatus(); } });
      listen(win, 'focus', () => { if (available()) invalidate(); });
      listen(win, 'online', invalidate);
      listen(win, 'offline', () => {
        clearPoll(); epoch += 1; dirty = true; abortFlight('网络连接已断开');
        const error = new Error('网络连接已断开'); settle(error); status('offline');
      });
      listen(win, 'pageshow', () => { pagePaused = false; invalidate(); });
      listen(win, 'pagehide', () => {
        pagePaused = true; clearPoll(); epoch += 1; dirty = true; abortFlight('页面已暂停同步');
        settle(new Error('页面已暂停同步')); status('paused');
      });
      listen(win, 'storage', event => { if (event.key === 'shopCatalogueChanged') invalidate(); });
      if (typeof Channel === 'function') {
        try {
          channel = new Channel('shop-catalogue');
          channel.onmessage = event => { if (event.data?.type === 'invalidate') invalidate(); };
        } catch (_) { channel = null; }
      }
      invalidate();
    }
    function stop() {
      if (!active) return;
      active = false; epoch += 1; dirty = false; clearPoll(); abortFlight('同步已停止'); flight = null;
      settle(new Error('同步已停止'));
      for (const remove of listeners.splice(0)) remove();
      if (channel) { channel.onmessage = null; try { channel.close(); } catch (_) {} channel = null; }
      status('stopped');
    }
    function refresh() {
      if (!active) return Promise.reject(new Error('同步尚未启动'));
      if (!online() || pagePaused || !visible()) {
        pauseStatus();
        return Promise.reject(new Error(!online() ? '网络连接已断开' : '页面已暂停同步'));
      }
      const result = new Promise((resolve, reject) => { waiters.push({ resolve, reject }); });
      invalidate();
      return result;
    }
    return { start, stop, refresh };
  }
  root.ShopLiveSync = { create };
})(typeof window !== 'undefined' ? window : globalThis);

