// 自助下单小铺 - 管理后台逻辑
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const yuan = (n) => '¥' + Number(n).toFixed(2);
const STATUS = { pending: '待付款', paid: '待确认', completed: '已完成', closed: '已关闭' };
const PAY = { wechat: '微信', alipay: '支付宝', wallet:'钱包余额' };

let token = sessionStorage.getItem('adminToken') || '';
let data = { settings: {}, products: [], orders: [] };
let orderFilter = 'paid';
const catalogueChannel = (() => {try {return typeof BroadcastChannel === 'function' ? new BroadcastChannel('shop-catalogue') : null;} catch {return null;}})();
function notifyStorefront() {
  try { catalogueChannel?.postMessage({type:'invalidate'}); } catch {}
  try { localStorage.setItem('shopCatalogueChanged', JSON.stringify({at:Date.now(),nonce:Math.random()})); } catch {}
}

async function api(url, opts = {}) {
  const res = await fetch(url, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (res.status === 401 && !url.endsWith('/login')) { clearAdminSession(); throw new Error('登录已过期，请重新登录'); }
  if (!res.ok) throw new Error(json.error || '请求失败');
  if (opts.method && !['GET','HEAD'].includes(opts.method) && /^\/api\/admin\/(products|settings|orders|upload)(?:\/|$)/.test(url)) notifyStorefront();
  return json;
}
function toast(msg) {
  const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), 2200);
}
function openModal(title, html, wide) {
  const root = $('#modalRoot');
  root.innerHTML = `<div class="mask"><div class="modal ${wide ? 'wide' : ''}"><div class="modal-head"><span>${esc(title)}</span><button class="modal-close">×</button></div><div class="modal-body">${html}</div></div></div>`;
  const close = () => (root.innerHTML = '');
  $('.modal-close', root).onclick = close;
  return { el: $('.modal-body', root), close };
}
const iconHtml = (icon) => (/^(\/|https?:)/.test(icon || '') ? `<img src="${esc(icon)}" alt="" />` : esc(icon || '📦'));

// ---------------- 登录 ----------------
async function login() {
  try {
    const r = await api('/api/admin/login', { method: 'POST', body: { password: $('#pwd').value } });
    token = r.token; sessionStorage.setItem('adminToken', token);
    await enter();
    if (r.defaultPassword) { toast('你正在使用初始密码，请到「设置」中修改'); location.hash = '#settings'; }
  } catch (e) { toast(e.message); }
}
function clearAdminSession() {
  token = ''; sessionStorage.removeItem('adminToken');
  $('#adminView').classList.add('hidden'); $('#loginView').classList.remove('hidden'); $('#pwd').value = '';
}
async function logout() {
  try { if (token) await fetch('/api/admin/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + token } }); }
  finally { clearAdminSession(); }
}
async function enter() {
  await reload();
  $('#loginView').classList.add('hidden'); $('#adminView').classList.remove('hidden');
  route();
}

// ---------------- 数据 ----------------
async function reload() {
  data = await api('/api/admin/data');
  $('#aShopName').textContent = data.settings.shopName || '管理后台';
  const wait = data.orders.filter((o) => o.status === 'paid').length;
  $('#badge').innerHTML = wait ? ` <span class="status st-pending" style="margin-left:auto">${wait}</span>` : '';
  document.title = (wait ? `(${wait}) ` : '') + '小铺管理后台';
  renderOrders(); renderProducts();
  if(location.hash==='#wallet' && typeof reloadAdminWallet==='function')await reloadAdminWallet();
}

async function renderDash() {
  const s = await api('/api/admin/stats');
  $('#stats').innerHTML = [
    ['待确认订单', s.waitConfirm], ['今日成交', s.todayOrders + ' 单'], ['今日销售额', yuan(s.todaySales)],
    ['累计销售额', yuan(s.totalSales)], ['累计订单', s.totalOrders],
  ].map(([l, n]) => `<div class="stat"><div class="l">${l}</div><div class="n">${n}</div></div>`).join('');
  if (!$('#shopUrl').value) $('#shopUrl').value = location.origin + '/';
  makeQr();
}

// 生成二维码 dataURL（使用本地 vendor/qrcode.js，无需联网）
function qrDataUrl(text, size = 300) {
  const qr = qrcode(0, 'M'); qr.addData(text); qr.make();
  const n = qr.getModuleCount(); const cell = Math.max(2, Math.floor(size / (n + 8)));
  const c = document.createElement('canvas'); c.width = c.height = (n + 8) * cell;
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#111';
  for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (qr.isDark(r, k)) g.fillRect((k + 4) * cell, (r + 4) * cell, cell, cell);
  return c;
}
function wrapText(g, text, maxW) {
  const lines = []; let line = '';
  for (const ch of text) { if (ch === '\n' || g.measureText(line + ch).width > maxW) { lines.push(line); line = ch === '\n' ? '' : ch; } else line += ch; }
  if (line) lines.push(line);
  return lines;
}
// 分享海报：店铺名 + 公告摘要 + 商品列表 + 进店二维码
function makeQr() {
  const url = $('#shopUrl').value.trim();
  const s = data.settings;
  const c = $('#poster'); const g = c.getContext('2d'); const W = c.width, H = c.height;
  const F = '"PingFang SC","Microsoft YaHei",sans-serif';
  const grd = g.createLinearGradient(0, 0, 0, H); grd.addColorStop(0, '#7fb2e5'); grd.addColorStop(1, '#5b8fd0');
  g.fillStyle = grd; g.fillRect(0, 0, W, H);
  g.fillStyle = '#f6b426'; roundRect(g, 60, 70, 96, 96, 22); g.fill();
  g.font = `52px ${F}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('🛍️', 108, 120);
  g.textAlign = 'left'; g.fillStyle = '#fff'; g.font = `bold 50px ${F}`; g.fillText((s.shopName || '小铺').slice(0, 10), 180, 105);
  g.font = `22px ${F}`; g.globalAlpha = .85; g.fillText(s.shopSubtitle || '', 182, 150); g.globalAlpha = 1;
  // 白色内容卡
  g.fillStyle = '#fff'; roundRect(g, 40, 210, W - 80, H - 250, 28); g.fill();
  g.fillStyle = '#1f2937'; g.font = `bold 30px ${F}`;
  wrapText(g, s.shareDesc || '自助选购，扫码下单', W - 160).slice(0, 2).forEach((line, i) => g.fillText(line, 80, 270 + i * 38));
  g.font = `24px ${F}`; let y = 365;
  for (const p of data.products.filter((x) => x.enabled !== false).slice(0, 5)) {
    const min = Math.min(...p.skus.map((k) => k.price));
    g.fillStyle = '#374151'; g.fillText('• ' + p.name.slice(0, 14), 80, y);
    g.fillStyle = '#c2410c'; g.textAlign = 'right'; g.fillText(`¥${min.toFixed(2)} 起`, W - 80, y); g.textAlign = 'left';
    y += 46;
  }
  // 二维码
  const qs = 300; const qx = (W - qs) / 2; const qy = H - 40 - 90 - qs - 20;
  if (url) g.drawImage(qrDataUrl(url, qs), qx, qy, qs, qs);
  g.textAlign = 'center'; g.fillStyle = '#6b7280'; g.font = `24px ${F}`;
  g.fillText('长按识别二维码 · 进店自助下单', W / 2, qy + qs + 40);
  g.textAlign = 'left';
  $('#shareText').value = `【${s.shopName}】${s.shareDesc || ''}\n👉 点击进店下单：${url}\n${s.contact ? '客服：' + s.contact.split('\n')[0] : ''}`.trim();
}
function roundRect(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function download(href, name) { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); }

// ---------------- 订单 ----------------
function renderOrders() {
  $$('#orderFilters [data-f]').forEach((b) => b.classList.toggle('btn-primary', b.dataset.f === orderFilter));
  const kw = $('#orderKw').value.trim();
  const list = data.orders.filter((o) => (orderFilter === 'all' || o.status === orderFilter) && (!kw || o.orderNo.includes(kw) || o.contact.includes(kw)));
  $('#orderRows').innerHTML = list.length ? list.map((o) => `<tr>
    <td>${esc(o.orderNo)}<div class="sub">${new Date(o.createdAt).toLocaleString()}</div></td>
    <td>${esc(o.productName)}<div class="sub">${esc(o.skuName)} × ${o.qty}</div></td>
    <td><b style="color:var(--price)">${yuan(o.amount)}</b></td>
    <td>${PAY[o.payMethod] || ''}</td>
    <td>${esc(o.contact)}${o.remark ? `<div class="sub">备注：${esc(o.remark)}</div>` : ''}</td>
    <td>${esc(o.payNote) || '<span class="sub">-</span>'}${o.paidAt ? `<div class="sub">${new Date(o.paidAt).toLocaleString()}</div>` : ''}</td>
    <td><span class="status st-${o.status}">${STATUS[o.status]}</span>${o.closeReason ? `<div class="sub">${esc(o.closeReason)}</div>` : ''}</td>
    <td style="white-space:nowrap">
      ${o.status === 'paid' ? `<button class="btn btn-ok btn-sm" data-confirm="${o.orderNo}">${o.payMethod==='wallet'?'完成交付':'确认收款'}</button> ` : ''}${['pending', 'paid'].includes(o.status) ? `<button class="btn btn-danger btn-sm" data-cancel="${o.orderNo}">关闭</button>` : ''}
      ${o.status === 'completed' ? `<button class="btn btn-sm" data-view-delivery="${o.orderNo}">发货内容</button>` : ''}
    </td></tr>`).join('') : `<tr><td colspan="8" class="empty">暂无订单</td></tr>`;
}

function confirmOrder(no) {
  const o = data.orders.find((x) => x.orderNo === no);
  const f = findSku(o.skuId);
  const hasCards = !!(o.hasAutomaticDelivery || o.hasReservedCards);
  const m = openModal(o.payMethod==='wallet'?'余额已支付，完成交付':'确认收款并完成订单', `
    <div class="kv"><span>订单</span><span>${esc(o.orderNo)}</span></div>
    <div class="kv"><span>商品</span><span>${esc(o.productName)} / ${esc(o.skuName)} × ${o.qty}</span></div>
    <div class="kv"><span>金额</span><span class="total">${yuan(o.amount)}</span></div>
    <div class="kv"><span>付款信息</span><span>${esc(o.payNote) || '-'}</span></div>
    <p class="tip">${o.payMethod==='wallet'?'此订单已从客户钱包扣款，请填写实际交付内容。关闭未交付订单会自动退回余额。':'⚠️ 请先在微信 / 支付宝中核对已收到这笔款项。'}${hasCards ? `<br/>该订单已预留自动发货内容，确认实际到账后按订单数量交付。` : ''}</p>
    <div class="field"><label>发货内容 / 给客户的留言（客户查单可见）</label>
      <textarea class="textarea" id="delivery" rows="4" placeholder="${hasCards ? '可留空，自动发送此订单预留的对应规格内容' : '如：交付链接、取货方式、预计完成时间等'}"></textarea></div>
    <div class="field"><button class="btn btn-ok btn-block" id="doConfirm">${o.payMethod==='wallet'?'完成交付':'确认收款'}</button></div>`);
  $('#doConfirm', m.el).onclick = async () => {
    try { await api(`/api/admin/orders/${no}/confirm`, { method: 'POST', body: { delivery: $('#delivery', m.el).value } }); m.close(); toast('订单已完成'); reload(); }
    catch (e) { toast(e.message); }
  };
}
async function cancelOrder(no) {
  const order=data.orders.find(o=>o.orderNo===no);
  const reason = prompt(order?.payMethod==='wallet'?'关闭原因（关闭后自动退回客户钱包余额）':'关闭原因（客户可见）', order?.payMethod==='wallet'?'无法交付，余额退回':'未收到付款');
  if (reason === null) return;
  try { await api(`/api/admin/orders/${no}/cancel`, { method: 'POST', body: { reason } }); toast('订单已关闭'); reload(); }
  catch (e) { toast(e.message); }
}

// ---------------- 商品 ----------------
function findSku(id) {
  for (const p of data.products) { const s = p.skus.find((x) => x.id === id); if (s) return { p, s }; }
  return null;
}
const modeOf = s => s.inventoryType || (s.cards?.length ? 'cards' : 'manual');
const stockOf = s => modeOf(s) === 'cards' ? (s.cards || []).length : s.stock;
const MODE_NAMES = {cards:'独立内容', shared:'固定内容', manual:'人工交付'};

function renderProducts() {
  $('#productRows').innerHTML = data.products.length ? data.products.map((p) => `<tr>
    <td>${p.sort || 0}</td>
    <td><div style="display:flex;gap:8px;align-items:center"><div class="picon">${iconHtml(p.icon)}</div><div><b>${esc(p.name)}</b>${p.tag ? `<div class="sub">${esc(p.tag)}</div>` : ''}</div></div></td>
    <td>${p.skus.map((s) => `<div>${esc(s.name)}：${yuan(s.price)} / 库存 ${stockOf(s)}（${MODE_NAMES[modeOf(s)]}）</div>`).join('')}</td>
    <td>${p.enabled !== false ? '<span class="status st-completed">上架</span>' : '<span class="status st-closed">下架</span>'}</td>
    <td style="white-space:nowrap"><button class="btn btn-sm" data-toggle="${p.id}">${p.enabled === false ? '上架' : '下架'}</button> <button class="btn btn-sm" data-edit="${p.id}">编辑</button> <button class="btn btn-danger btn-sm" data-del="${p.id}">删除</button></td>
  </tr>`).join('') : `<tr><td colspan="5" class="empty">还没有商品，点击右上角新增</td></tr>`;
}

function skuRow(s = {}) {
  const mode = modeOf(s);
  return `<div class="sku-edit" data-sku-id="${esc(s.id || '')}">
    <label class="sku-field">规格名称<input class="input" data-k="name" placeholder="例如 Go / Plus" value="${esc(s.name || '')}" /></label>
    <label class="sku-field">单价（元）<input class="input" data-k="price" type="number" step="0.01" min="0" value="${s.price ?? ''}" /></label>
    <label class="sku-field"><span data-stock-label>剩余可售库存</span><input class="input" data-k="stock" type="number" min="0" step="1" value="${s.stock ?? 0}" /></label>
    <button class="btn btn-danger btn-sm sku-remove" data-rm-sku>删除</button>
    <label class="sku-wide sku-field">发货方式<select class="select" data-k="inventoryType">
      <option value="cards" ${mode==='cards'?'selected':''}>独立内容 · 每件一条，用后不重复发</option>
      <option value="shared" ${mode==='shared'?'selected':''}>固定内容 · 同一规格共用，库存单独设置</option>
      <option value="manual" ${mode==='manual'?'selected':''}>人工交付 · 确认收款时填写内容</option>
    </select></label>
    <label class="sku-wide sku-field" data-unique>此规格剩余的独立内容（每行一件）<textarea class="textarea" data-k="cards" rows="4" placeholder="第 1 件完整内容写在第一行&#10;第 2 件完整内容写在第二行">${esc((s.cards || []).join('\n'))}</textarea></label>
    <div class="sku-wide sku-import" data-unique-tools><button type="button" class="btn btn-sm" data-import-cards>导入 TXT 追加库存</button><input type="file" accept=".txt,text/plain" data-cards-file hidden /><span class="tip">UTF-8 文本，每行一件；保存商品后生效</span></div>
    <label class="sku-wide sku-field" data-shared>此规格的固定发货内容<textarea class="textarea" data-k="deliveryContent" rows="4" placeholder="每位购买此规格的客户收到这份内容，支持多行">${esc(s.deliveryContent || '')}</textarea></label>
    <div class="tip sku-wide" data-stock-hint role="status"></div>
  </div>`;
}
function updateSkuEditor(row) {
  const mode = $('[data-k=inventoryType]',row).value;
  const stock = $('[data-k=stock]',row);
  $('[data-unique]',row).hidden = mode !== 'cards';
  $('[data-unique-tools]',row).hidden = mode !== 'cards';
  $('[data-shared]',row).hidden = mode !== 'shared';
  $('[data-stock-label]',row).textContent = mode === 'cards' ? '剩余库存（按内容计数）' : '剩余可售库存';
  if (mode !== 'cards' && stock.readOnly) stock.value = row.dataset.numericStock || '0';
  if (mode === 'cards' && !stock.readOnly) row.dataset.numericStock = stock.value;
  stock.readOnly = mode === 'cards';
  let hint;
  if (mode === 'cards') {
    const lines = $('[data-k=cards]',row).value.split('\n').map(v=>v.trim()).filter(Boolean);
    stock.value = lines.length;
    hint = '有效内容 ' + lines.length + ' 条 = 可售 ' + lines.length + ' 件。增加或移除下方内容即可调整库存；也可导入 TXT 批量追加。客户买 20 件，就收到此规格的 20 条不同内容，其他规格不受影响。';
    if (new Set(lines).size !== lines.length) hint = '存在重复内容，请删除重复行后保存。' + hint;
  } else if (mode === 'shared') {
    hint = '库存按上方数量扣减，不受内容行数影响。每位购买此规格的客户收到相同内容；其他规格使用各自的内容。';
  } else hint = '库存按上方数量扣减；确认收款时手动填写给客户的内容。';
  $('[data-stock-hint]',row).textContent = hint;
}

function editProduct(id) {
  const p = data.products.find((x) => x.id === id) || { name: '', icon: '📦', tag: '', sort: data.products.length + 1, enabled: true, skus: [{}] };
  const expectedRevision = p.revision || 0;
  const m = openModal(id ? '编辑商品' : '新增商品', `
    <div class="row">
      <div class="field"><label>商品名称 *</label><input class="input" id="pName" value="${esc(p.name)}" /></div>
      <div class="field"><label>角标（如：售后保障）</label><input class="input" id="pTag" maxlength="20" value="${esc(p.tag)}" /></div>
    </div>
    <div class="row">
      <div class="field"><label>图标（填 emoji，或上传图片）</label>
        <div style="display:flex;gap:8px;align-items:center"><div class="picon" id="pIconPv">${iconHtml(p.icon)}</div>
        <input class="input" id="pIcon" value="${esc(p.icon)}" /></div>
        <input type="file" accept="image/*" id="pIconFile" style="margin-top:6px" /></div>
      <div class="field"><label>排序（数字小的在前）</label><input class="input" id="pSort" type="number" value="${p.sort || 0}" />
        <label style="margin-top:10px"><input type="checkbox" id="pEnabled" ${p.enabled !== false ? 'checked' : ''} /> 上架销售</label></div>
    </div>
    <p class="tip">各规格独立扣库存、独立发货。客户下单后预留库存；核实到账并确认收款后，系统自动交付。未付款超时或关闭订单会恢复库存。</p><div class="field"><label>规格 / 价格 / 库存</label><div id="skuList">${p.skus.map(skuRow).join('')}</div>
      <button class="btn btn-sm" id="btnAddSku">＋ 添加规格</button></div>
    <div class="field"><button class="btn btn-primary btn-block" id="btnSaveProduct">保存</button></div>`, true);

  $('#pIcon', m.el).oninput = (e) => ($('#pIconPv', m.el).innerHTML = iconHtml(e.target.value));
  $('#pIconFile', m.el).onchange = async (e) => {
    const url = await uploadFile(e.target.files[0]); if (!url) return;
    $('#pIcon', m.el).value = url; $('#pIconPv', m.el).innerHTML = iconHtml(url);
  };
  $$('.sku-edit', m.el).forEach(updateSkuEditor);
  m.el.addEventListener('input', e => { const row = e.target.closest('.sku-edit'); if (row) updateSkuEditor(row); });
  m.el.addEventListener('change', async e => {
    const row = e.target.closest('.sku-edit'); if (!row) return;
    if (e.target.matches('[data-cards-file]')) {
      const file = e.target.files[0]; if (!file) return;
      try {
        if (!/\.txt$/i.test(file.name) || file.size > 1024 * 1024) throw new Error('请选择不超过 1MB 的 UTF-8 TXT 文本');
        const text = await file.text();
        if (!row.isConnected) return;
        if (text.includes('\uFFFD') || text.includes('\0')) throw new Error('请将文件另存为 UTF-8 编码后再导入');
        if ($('[data-k=inventoryType]',row).value !== 'cards') throw new Error('请先选择独立内容发货方式');
        const textarea = $('[data-k=cards]',row), current = textarea.value.split('\n').map(v=>v.trim()).filter(Boolean);
        const incoming = text.split(/\r\n?|\n/).map(v=>v.trim()).filter(Boolean);
        const seen = new Set(current), added = incoming.filter(v=>{ if (seen.has(v)) return false; seen.add(v); return true; });
        if (current.length + added.length > 10000 || added.some(v=>v.length > 4000)) throw new Error('最多 10000 件，每件内容不能超过 4000 字');
        textarea.value = [...current, ...added].join('\n');
        toast(`已追加 ${added.length} 条${incoming.length > added.length ? `，跳过 ${incoming.length-added.length} 条重复内容` : ''}，请保存商品`);
      } catch (error) { toast(error.message); }
      finally { e.target.value = ''; }
    }
    updateSkuEditor(row);
  });
  $('#btnAddSku', m.el).onclick = () => { $('#skuList', m.el).insertAdjacentHTML('beforeend', skuRow({inventoryType:'cards'})); updateSkuEditor($('#skuList',m.el).lastElementChild); };
  m.el.addEventListener('click', (e) => {
    const row = e.target.closest('.sku-edit');
    if (e.target.matches('[data-rm-sku]')) row.remove();
    if (e.target.matches('[data-import-cards]')) $('[data-cards-file]',row).click();
  });
  $('#btnSaveProduct', m.el).onclick = async () => {
    const skus = $$('.sku-edit', m.el).map((r) => ({
      id: r.dataset.skuId || undefined,
      name: $('[data-k=name]', r).value, price: $('[data-k=price]', r).value,
      stock: $('[data-k=stock]', r).value, cards: $('[data-k=cards]', r).value,
      inventoryType: $('[data-k=inventoryType]',r).value, deliveryContent: $('[data-k=deliveryContent]',r).value,
    }));
    try {
      await api('/api/admin/products', { method: 'POST', body: {
        id: id || undefined, expectedRevision, name: $('#pName', m.el).value, tag: $('#pTag', m.el).value, icon: $('#pIcon', m.el).value,
        sort: $('#pSort', m.el).value, enabled: $('#pEnabled', m.el).checked, skus } });
      m.close(); toast('已保存'); reload();
    } catch (e) { toast(e.message); }
  };
}
async function toggleProduct(id, button) {
  const p = data.products.find(product => product.id === id);
  if (!p) return;
  button.disabled = true;
  try {
    const enabled = p.enabled === false;
    await api('/api/admin/products/' + encodeURIComponent(id) + '/visibility', {method:'PATCH',body:{enabled}});
    toast(enabled ? '已上架，客户前台会自动显示' : '已下架，客户前台会自动移除');
    await reload();
  } catch (error) {toast(error.message); button.disabled = false;}
}
async function delProduct(id) {
  const p = data.products.find((x) => x.id === id);
  if (!confirm(`确定删除「${p.name}」吗？`)) return;
  await api('/api/admin/products/' + id, { method: 'DELETE' }); toast('已删除'); reload();
}

// ---------------- 设置 ----------------
function renderSettings() {
  const s = data.settings;
  $('#pwdWarn').classList.toggle('hidden', !s.mustChangePwd);
  $('#sName').value = s.shopName || ''; $('#sSub').value = s.shopSubtitle || '';
  $('#sNotice').value = s.notice || ''; $('#sContact').value = s.contact || ''; $('#sPwd').value = '';
  $('#sWechatCode').value = s.wechatPayCode || ''; $('#sAlipayCode').value = s.alipayPayCode || '';
  $('#sShareDesc').value = s.shareDesc || ''; $('#pvShare').src = s.shareImage || '';
  previewCode('wechat'); previewCode('alipay');
}
function previewCode(kind) {
  const code = $(kind === 'wechat' ? '#sWechatCode' : '#sAlipayCode').value.trim();
  const img = $(kind === 'wechat' ? '#pvWechat' : '#pvAlipay');
  try { img.src = code ? qrDataUrl(code, 280).toDataURL() : ''; } catch { img.removeAttribute('src'); }
}
// 在浏览器本地识别收款码图片
async function decodeQrFile(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = url; });
    const scale = Math.min(1, 1600 / Math.max(img.width, img.height));
    const c = document.createElement('canvas'); c.width = img.width * scale; c.height = img.height * scale;
    const g = c.getContext('2d'); g.drawImage(img, 0, 0, c.width, c.height);
    const d = g.getImageData(0, 0, c.width, c.height);
    const r = jsQR(d.data, d.width, d.height);
    return r ? r.data : null;
  } finally { URL.revokeObjectURL(url); }
}
function readAsDataUrl(file) {
  return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
}
async function uploadFile(file, target) {
  if (!file) return null;
  if (!['image/png', 'image/jpeg', 'image/gif', 'image/webp'].includes(file.type)) { toast('请上传 PNG、JPG、GIF 或 WEBP 图片'); return null; }
  if (file.size > 1024 * 1024) { toast('图片不能超过 1MB'); return null; }
  try { const r = await api('/api/admin/upload', { method: 'POST', body: { dataUrl: await readAsDataUrl(file), target } }); return r.url; }
  catch (e) { toast(e.message); return null; }
}

// ---------------- 路由 / 事件 ----------------
function route() {
  const view = (location.hash || '#dash').slice(1);
  let v = ['dash', 'orders', 'products', 'settings', 'wallet'].includes(view) ? view : 'dash';
  if (data.settings.mustChangePwd && v !== 'settings') { v = 'settings'; toast('请先修改初始密码'); history.replaceState(null, '', '#settings'); }
  ['dash', 'orders', 'products', 'settings', 'wallet'].forEach((x) => $('#view-' + x).classList.toggle('hidden', x !== v));
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === v));
  if (v === 'dash') renderDash().catch((e) => toast(e.message));
  if (v === 'settings') renderSettings();
  if(v==='wallet' && typeof reloadAdminWallet==='function')reloadAdminWallet().catch(e=>toast(e.message));
}

document.addEventListener('click', (e) => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.confirm) confirmOrder(t.dataset.confirm);
  else if (t.dataset.cancel) cancelOrder(t.dataset.cancel);
  else if (t.dataset.viewDelivery) { const o = data.orders.find((x) => x.orderNo === t.dataset.viewDelivery); openModal('发货内容', `<div class="delivery">${esc(o.delivery)}</div>`); }
  else if (t.dataset.toggle) toggleProduct(t.dataset.toggle, t);
  else if (t.dataset.edit) editProduct(t.dataset.edit);
  else if (t.dataset.del) delProduct(t.dataset.del).catch((er) => toast(er.message));
  else if (t.dataset.f) { orderFilter = t.dataset.f; renderOrders(); }
});
$('#btnLogin').onclick = login;
$('#pwd').addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
$('#btnLogout').onclick = logout;
$('#btnAddProduct').onclick = () => editProduct(null);
$('#btnReloadOrders').onclick = () => reload().then(() => toast('已刷新'));
$('#orderKw').addEventListener('input', renderOrders);
$('#btnMakeQr').onclick = makeQr;
$('#shopUrl').addEventListener('change', makeQr);
$('#btnDownQr').onclick = () => download(qrDataUrl($('#shopUrl').value.trim(), 600).toDataURL('image/png'), 'shop-qrcode.png');
$('#btnDownPoster').onclick = () => download($('#poster').toDataURL('image/png'), 'shop-poster.png');
$('#btnCopyShare').onclick = async () => {
  try { await navigator.clipboard.writeText($('#shareText').value); toast('已复制，去微信粘贴发送吧'); }
  catch { $('#shareText').select(); document.execCommand('copy'); toast('已复制'); }
};
$$('[data-decode]').forEach((inp) => (inp.onchange = async () => {
  const kind = inp.dataset.decode; const file = inp.files[0]; if (!file) return;
  const code = await decodeQrFile(file).catch(() => null);
  inp.value = '';
  if (!code) { toast('没有识别到二维码，请换一张更清晰的截图'); return; }
  if (kind === 'wechat' && !/^wxp:\/\//i.test(code)) { toast('请选择有效的微信收款码'); return; }
  if (kind === 'alipay' && !/^https:\/\/qr\.alipay\.com\//i.test(code)) { toast('请选择有效的支付宝收款码'); return; }
  $(kind === 'wechat' ? '#sWechatCode' : '#sAlipayCode').value = code;
  previewCode(kind);
  toast('识别成功，点击「保存设置」生效');
}));
$('#sWechatCode').addEventListener('input', () => previewCode('wechat'));
$('#sAlipayCode').addEventListener('input', () => previewCode('alipay'));
$('#shareFile').onchange = async (e) => {
  const url = await uploadFile(e.target.files[0], 'shareImage');
  if (url) { data.settings.shareImage = url; $('#pvShare').src = url; toast('封面图已更新'); }
};
$('#btnSaveSettings').onclick = async () => {
  if ($('#sPwd').value && $('#sPwd').value.length < 12) { toast('管理员密码至少 12 位'); return; }
  try {
    const r = await api('/api/admin/settings', { method: 'PUT', body: {
      shopName: $('#sName').value, shopSubtitle: $('#sSub').value, notice: $('#sNotice').value,
      contact: $('#sContact').value, shareDesc: $('#sShareDesc').value,
      wechatPayCode: $('#sWechatCode').value, alipayPayCode: $('#sAlipayCode').value,
      newPassword: $('#sPwd').value } });
    if (r.needLogin || $('#sPwd').value) { clearAdminSession(); toast('密码已更新，请使用新密码重新登录'); return; }
    toast(r.mustChangePwd ? '已保存，请修改管理员密码' : '设置已保存');
    await reload(); renderSettings();
  } catch (e) { toast(e.message); }
};
window.addEventListener('hashchange', route);
setInterval(() => { if (token) reload().catch(() => {}); }, 15000); // 每 15 秒自动刷新新订单

if (token) enter().catch(() => clearAdminSession());
$('#btnExport').onclick = async () => {
  try {
    const res = await fetch('/api/admin/export', { headers: { Authorization: 'Bearer ' + token } });
    if (!res.ok) { if (res.status === 401) clearAdminSession(); throw new Error('导出失败，请重新登录后重试'); }
    const url = URL.createObjectURL(await res.blob());
    download(url, 'shop-backup-' + new Date().toISOString().slice(0,10) + '.json');
    setTimeout(() => URL.revokeObjectURL(url), 30000); toast('备份已导出，内含订单资料，请妥善保管');
  } catch (e) { toast(e.message); }
};

