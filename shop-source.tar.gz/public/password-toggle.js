// Add a local visibility control to static and dynamically opened password fields.
(() => {
  const enhanced = new WeakSet();
  const eye = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/><path class="password-eye-slash" d="m3 3 18 18"/></svg>';
  function setVisible(input, button, visible) {
    input.type = visible ? 'text' : 'password';
    button.setAttribute('aria-pressed', String(visible));
    button.setAttribute('aria-label', visible ? '隐藏密码' : '显示密码');
    button.title = visible ? '隐藏密码' : '显示密码';
  }
  function enhance(root) {
    const fields = root.matches?.('input[type="password"]') ? [root] : [...(root.querySelectorAll?.('input[type="password"]') || [])];
    for (const input of fields) {
      if (enhanced.has(input)) continue;
      enhanced.add(input);
      const wrap = document.createElement('div'); wrap.className = 'password-wrap';
      input.before(wrap); wrap.append(input);
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'password-toggle';
      if (input.id) button.setAttribute('aria-controls', input.id);
      button.innerHTML = eye;
      setVisible(input, button, false);
      button.addEventListener('click', () => {
        const start = input.selectionStart, end = input.selectionEnd;
        setVisible(input, button, input.type === 'password');
        if (start !== null && end !== null) input.setSelectionRange(start, end);
      });
      wrap.append(button);
    }
  }
  function concealAll() {
    document.querySelectorAll('.password-wrap').forEach(wrap => {
      const input = wrap.querySelector('input'), button = wrap.querySelector('.password-toggle');
      if (input && button) setVisible(input, button, false);
    });
  }
  enhance(document);
  new MutationObserver(records => {
    for (const record of records) for (const node of record.addedNodes) if (node.nodeType === 1) enhance(node);
  }).observe(document.body, {childList:true, subtree:true});
  window.addEventListener('hashchange', concealAll);
  document.addEventListener('visibilitychange', () => { if (document.hidden) concealAll(); });
})();
