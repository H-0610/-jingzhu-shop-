let walletData={ledger:[],topups:[]}, walletLoading=false;
const TOPUP_STATUS={pending:'待付款',paid:'待商家核对',credited:'已入账',closed:'已关闭'};
const FLOW_NAME={topup:'充值入账',purchase:'采购扣款',refund:'退回余额'};
const beijing=value=>new Date(value).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
async function refreshWallet() {
  if(walletLoading)return;walletLoading=true;
  try {
    const next=await api('/api/customer/wallet',{signal:AbortSignal.timeout(15000)});
    customer=next.customer;walletData=next;renderWallet();checkoutChanged?.();
    $('#walletSync').textContent='数据更新于 '+beijing(new Date())+'（北京时间）';
  } catch(e) {
    if(e.status===401){customer=null;walletData={ledger:[],topups:[]};renderWallet();checkoutChanged?.();}
    else {$('#walletSync').textContent='暂未同步成功，请检查网络后刷新';throw e;}
  } finally {walletLoading=false;}
}
function renderWallet() {
  $('#walletGuest').classList.toggle('hidden',!!customer);$('#walletMember').classList.toggle('hidden',!customer);
  $('#walletSide').textContent=customer?'可用余额 '+yuan(customer.balance):'登录查看钱包余额';
  if(!customer){$('#walletSync').textContent='登录后查看余额和记录';return;}
  $('#walletAccountName').textContent='客户账号：'+customer.username;
  $('#walletBalance').textContent=yuan(customer.balance);$('#walletTopupTotal').textContent=yuan(customer.totalTopup);$('#walletSpent').textContent=yuan((Math.round(customer.totalSpent*100)-Math.round(customer.totalRefund*100))/100);
  $('#walletRefundInfo').textContent='累计退回余额 '+yuan(customer.totalRefund);
  $('#walletTopups').innerHTML=walletData.topups.length?walletData.topups.map(t=>`<div class="topup-row"><div><b>${yuan(t.amount)}</b> <span class="status st-${t.status==='credited'?'completed':t.status}">${TOPUP_STATUS[t.status]}</span><p class="tip">${esc(t.topupNo)} · ${beijing(t.createdAt)} · ${PAY[t.payMethod]}</p>${t.closeReason?`<p class="tip">${esc(t.closeReason)}</p>`:''}</div><div class="head-actions">${t.status==='pending'?`<button class="btn btn-sm btn-primary" data-topup-pay="${t.topupNo}">继续付款</button><button class="btn btn-sm" data-topup-cancel="${t.topupNo}">取消</button>`:''}</div></div>`).join(''):'<div class="empty">还没有充值记录，点击右上角充值</div>';
  renderWalletLedger();
}
function renderWalletLedger() {
  const filter=$('#walletFilter').value,list=walletData.ledger.filter(l=>filter==='all'||l.type===filter);
  $('#walletRows').innerHTML=list.length?list.map(l=>`<tr><td><span class="flow-pill flow-${l.type}">${FLOW_NAME[l.type]}</span></td><td class="flow-${l.type}">${l.amount>=0?'+':'−'}${yuan(Math.abs(l.amount))}</td><td>${yuan(l.balance)}</td><td>${esc(l.remark)}</td><td>${l.type==='topup'?esc(l.relatedNo):`<button class="btn btn-sm" data-wallet-order="${l.relatedNo}">${l.relatedNo}</button>`}</td><td>${beijing(l.createdAt)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">暂无钱包流水</td></tr>';
}
function customerLogin(mode='login') {
  const register=mode==='register',recover=mode==='recover';
  const m=openModal(recover?'使用恢复码找回账号':register?'注册客户账号':'登录客户账号',`<form id="customerForm"><div class="field"><label for="customerName">账号</label><input class="input" id="customerName" required minlength="4" maxlength="40" autocomplete="username" placeholder="4–40位字母、数字、下划线或短横线" /></div>${recover?'<div class="field"><label for="customerRecovery">注册时保存的恢复码</label><input class="input" id="customerRecovery" required maxlength="64" autocomplete="off" /></div>':''}<div class="field"><label for="customerPassword">${recover?'新密码':'密码'}</label><input class="input" id="customerPassword" type="password" required minlength="12" maxlength="128" autocomplete="${register||recover?'new-password':'current-password'}" placeholder="至少12位，请设置独立密码" /></div>${register||recover?'<div class="field"><label for="customerPasswordAgain">再次输入密码</label><input class="input" id="customerPasswordAgain" type="password" required minlength="12" maxlength="128" autocomplete="new-password" /></div>':''}<p id="customerError" class="form-error" role="alert"></p><button class="btn btn-primary btn-block" type="submit" id="customerSubmit">${recover?'重设密码':register?'注册并登录':'登录'}</button></form><div class="wallet-auth-actions"><button class="btn btn-sm" data-auth-mode="${register||recover?'login':'register'}">${register||recover?'返回登录':'没有账号？注册'}</button>${!recover?'<button class="btn btn-sm" data-auth-mode="recover">忘记密码</button>':''}</div><p class="tip">这是本店客户账号，与微信、支付宝账号分开。无需提供支付平台密码。</p>`);
  $$('[data-auth-mode]',m.el).forEach(b=>b.onclick=()=>customerLogin(b.dataset.authMode));
  $('#customerForm',m.el).onsubmit=async e=>{
    e.preventDefault();const button=$('#customerSubmit',m.el);if(button.disabled)return;
    if((register||recover) && $('#customerPassword',m.el).value!==$('#customerPasswordAgain',m.el).value){$('#customerError',m.el).textContent='两次输入的密码不一致';return;}
    button.disabled=true;
    try {
      const result=await api('/api/customer/'+mode,{method:'POST',body:{username:$('#customerName',m.el).value,password:$('#customerPassword',m.el).value,recoveryCode:recover?$('#customerRecovery',m.el).value:undefined}});
      customer=result.customer;m.close();await refreshWallet();
      if(result.recoveryCode){const credential=`店铺：${location.origin}\n客户账号：${customer.username}\n恢复码：${result.recoveryCode}\n恢复码可重设密码，请勿分享。`;
        const recovery=openModal('请保存账号恢复码',`<p>忘记密码时可用此码找回余额账户。${recover?'原恢复码已失效。':''}恢复码只显示这一次。</p><div class="delivery">${esc(credential)}</div><button class="btn btn-primary btn-block" id="copyRecovery">复制账号和恢复码</button>`);$('#copyRecovery',recovery.el).onclick=()=>copyText(credential,'已复制，请保存到安全位置').catch(e=>toast(e.message));
      }else toast('登录成功');
    }catch(error){if(m.el.isConnected){$('#customerError',m.el).textContent=error.message;button.disabled=false;}}
  };
}
function rechargeWallet() {
  if(!customer){customerLogin();return;}
  const available=['alipay','wechat'].filter(p=>shop?.pay[p]);
  if(!available.length){toast('商家暂未设置收款方式，请联系客服');return;}
  const nonce=crypto.randomUUID();
  const m=openModal('充值到我的钱包',`<p class="tip">当前账号：${esc(customer.username)} · 可用余额 ${yuan(customer.balance)}</p><form id="rechargeForm"><div class="field"><label for="rechargeAmount">充值金额（元）</label><input class="input" type="number" id="rechargeAmount" min="1" max="10000" step="0.01" value="100" required /></div><div class="wallet-presets">${[50,100,200,500].map(n=>`<button class="btn btn-sm" type="button" data-recharge-amount="${n}">¥${n}</button>`).join('')}</div><div class="field"><label for="rechargeMethod">支付方式</label><select class="select" id="rechargeMethod">${available.map(p=>`<option value="${p}">${PAY[p]}</option>`).join('')}</select></div><p class="wallet-note">充值款直接进入商家的收款账户。请按显示金额付款并提交付款信息，商家核对到账后才会增加余额；请勿重复支付。</p><p class="form-error" id="rechargeError" role="alert"></p><button type="submit" class="btn btn-primary btn-block" id="rechargeSubmit">生成充值单</button></form>`);
  $$('[data-recharge-amount]',m.el).forEach(b=>b.onclick=()=>$('#rechargeAmount',m.el).value=b.dataset.rechargeAmount);
  $('#rechargeForm',m.el).onsubmit=async e=>{e.preventDefault();const b=$('#rechargeSubmit',m.el);if(b.disabled)return;b.disabled=true;try {const {topup}=await api('/api/customer/topups',{method:'POST',body:{amount:Number($('#rechargeAmount',m.el).value),payMethod:$('#rechargeMethod',m.el).value,requestId:nonce}});showTopupPayment(topup);await refreshWallet();}catch(error){if(m.el.isConnected){$('#rechargeError',m.el).textContent=error.message;b.disabled=false;}}};
}
function showTopupPayment(t) {
  if(t.status!=='pending'||!t.payment){refreshWallet().catch(e=>toast(e.message));return;}
  const image=renderPayQr(t.payment.code,t.payMethod,t.amount);
  const m=openModal('充值付款',`<div class="kv"><span>充值单号</span><b>${esc(t.topupNo)}</b></div><div class="kv"><span>请支付</span><span class="total">${yuan(t.amount)}</span></div><div class="wallet-qr"><img src="${image}" alt="${PAY[t.payMethod]}充值收款码" /></div><p class="tip">请使用${PAY[t.payMethod]}扫码或长按保存图片后识别，核对收款方并输入准确金额。资金直接进入商家账户。</p><button class="btn btn-sm" id="topupSaveQr">保存收款码</button><div class="field"><label for="topupPayNote">付款信息</label><input class="input" id="topupPayNote" maxlength="200" placeholder="支付账单号，或付款时间、付款方备注" /></div><p class="form-error" id="topupError" role="alert"></p><button class="btn btn-primary btn-block" id="topupPaid">我已付款，提交核对</button><p class="tip">提交后请勿重复付款。核对到账并入账后，钱包余额会自动更新。</p>`);
  $('#topupSaveQr',m.el).onclick=()=>{const a=document.createElement('a');a.href=image;a.download='充值收款码-'+t.topupNo+'.png';a.click();};
  $('#topupPaid',m.el).onclick=async()=>{const b=$('#topupPaid',m.el);if(b.disabled)return;b.disabled=true;try{await api('/api/customer/topups/'+t.topupNo+'/paid',{method:'POST',body:{payNote:$('#topupPayNote',m.el).value}});m.close();await refreshWallet();toast('已提交，商家核对到账后入账');}catch(e){$('#topupError',m.el).textContent=e.message;b.disabled=false;}};
}
$('#walletLogin').onclick=()=>customerLogin();$('#walletRecharge').onclick=rechargeWallet;
$('#walletRefresh').onclick=()=>refreshWallet().then(()=>toast(customer?'钱包已刷新':'请先登录')).catch(e=>toast(e.message));
$('#walletFilter').onchange=renderWalletLedger;
$('#walletLogout').onclick=async()=>{try{await api('/api/customer/logout',{method:'POST'});customer=null;walletData={ledger:[],topups:[]};lastOrders=[];$('#queryResult').innerHTML='';$('#queryKw').value='';$('#queryKey').value='';localStorage.removeItem('myOrdersV2');renderWallet();checkoutChanged?.();toast('已退出登录');}catch(e){toast(e.message);}};
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;try{
  if(b.dataset.topupPay)showTopupPayment(walletData.topups.find(t=>t.topupNo===b.dataset.topupPay));
  if(b.dataset.topupCancel){b.disabled=true;await api('/api/customer/topups/'+b.dataset.topupCancel+'/cancel',{method:'POST'});await refreshWallet();}
  if(b.dataset.walletOrder){$('#queryKw').value=b.dataset.walletOrder;$('#queryKey').value='';location.hash='#query';await doQuery();}
}catch(error){toast(error.message);b.disabled=false;}});
refreshWallet().catch(()=>{});
setInterval(()=>{if(!document.hidden && (location.hash==='#wallet'||customer))refreshWallet().catch(()=>{});},5000);
window.addEventListener('focus',()=>refreshWallet().catch(()=>{}));
