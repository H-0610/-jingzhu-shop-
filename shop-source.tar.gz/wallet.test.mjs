import test from 'node:test';
import assert from 'node:assert/strict';
import {PGlite} from '@electric-sql/pglite';
import {startShop} from './server.mjs';
import {postgresAdapter,initializePostgres} from './postgres.mjs';
import {prepareBackup} from './tools/import-state.mjs';
const password='Wallet-Local-Test-Only-2026!';
const cards=Array.from({length:20},(_,i)=>`GO-PRIVATE-${i+1}`);
const seed={settings:{shopName:'钱包本地验证',wechatPayCode:'wxp://wallet-local-test',alipayPayCode:'https://qr.alipay.com/local-test'},products:[{id:'p',name:'钱包测试商品',enabled:true,skus:[
  {id:'go',name:'Go',price:30,stock:20,inventoryType:'cards',cards},
  {id:'plus',name:'Plus',price:109,stock:99,inventoryType:'shared',cards:[],deliveryContent:'PLUS-PRIVATE'},
  {id:'race',name:'并发验证',price:60,stock:2,inventoryType:'shared',cards:[],deliveryContent:'SHARED-PRIVATE'},
  {id:'manual',name:'人工交付',price:10,stock:2,inventoryType:'manual',cards:[]}
]}],orders:[]};
for(const engine of ['sqlite','postgres'])test(`${engine}: wallet funding, concurrent purchases, independent delivery, recovery and backup stay atomic`,async t=>{
  let database;
  if(engine==='postgres'){const pg=new PGlite();await initializePostgres(sql=>pg.query(sql));database=postgresAdapter((sql,args)=>pg.query(sql,args),()=>pg.close());}
  const service=await startShop({port:0,filename:':memory:',database,password,seed,origin:'https://wallet.example.test'});t.after(()=>service.close());
  const call=async(path,{method='GET',body,cookie='',token='',headers={}}={})=>{
    const res=await fetch(`http://127.0.0.1:${service.port}${path}`,{method,headers:{'content-type':'application/json','x-wallet-request':'1',cookie,...(token?{authorization:'Bearer '+token}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});
    return {status:res.status,body:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0],setCookie:res.headers.get('set-cookie')};
  };
  const admin=(await call('/api/admin/login',{method:'POST',body:{password}})).body.token;
  const signup=await call('/api/customer/register',{method:'POST',body:{username:'wallet_user',password,balance:99999}});
  assert.equal(signup.status,200);assert.equal(signup.body.customer.balance,0);assert.match(signup.setCookie,/HttpOnly/);assert.match(signup.setCookie,/SameSite=Strict/);assert.match(signup.setCookie,/Secure/);assert.equal(signup.body.recoveryCode.length,64);
  let cookie=signup.cookie;
  const outsider=(await call('/api/customer/register',{method:'POST',body:{username:'another_user',password}})).cookie;
  const wallet=async()=>{const r=await call('/api/customer/wallet',{cookie});assert.equal(r.status,200);return r.body;};
  const stock=async()=> (await call('/api/shop')).body.products[0].skus.map(s=>s.stock);
  const purchase=(skuId,qty,id=crypto.randomUUID(),extra={})=>call('/api/orders',{method:'POST',cookie,body:{skuId,qty,requestId:id,payMethod:'wallet',contact:'local-test',...extra}});
  assert.equal((await call('/api/customer/wallet')).status,401);
  assert.equal((await call('/api/admin/wallet',{cookie})).status,401);
  assert.equal((await call('/api/customer/topups',{method:'POST',cookie,headers:{origin:'https://evil.example'},body:{amount:100,payMethod:'wechat',requestId:crypto.randomUUID()}})).status,403);
  assert.equal((await purchase('go',20)).status,409);assert.deepEqual(await stock(),[20,99,2,2]);
  for(const amount of [-1,0,1.001,10001,'100'])assert.equal((await call('/api/customer/topups',{method:'POST',cookie,body:{amount,payMethod:'wechat',requestId:crypto.randomUUID()}})).status,400);
  const nonce=crypto.randomUUID(),create=()=>call('/api/customer/topups',{method:'POST',cookie,body:{amount:600,payMethod:'wechat',requestId:nonce}});
  const topup=(await create()).body.topup;assert.equal((await create()).body.topup.topupNo,topup.topupNo);assert.equal(topup.payment.code,seed.settings.wechatPayCode);
  const confirm=(no,ref='TXN_001')=>call('/api/admin/topups/'+no+'/confirm',{method:'POST',token:admin,body:{paymentReference:ref}});
  assert.equal((await confirm(topup.topupNo)).status,409);assert.equal((await wallet()).customer.balance,0);
  assert.equal((await call('/api/customer/topups/'+topup.topupNo+'/paid',{method:'POST',cookie:outsider,body:{payNote:'TXN_001'}})).status,404);
  assert.equal((await call('/api/customer/topups/'+topup.topupNo+'/paid',{method:'POST',cookie,body:{payNote:'TXN_001'}})).status,200);assert.equal((await wallet()).customer.balance,0);
  const credited=await Promise.all([confirm(topup.topupNo),confirm(topup.topupNo)]);assert.ok(credited.every(r=>r.status===200));assert.equal((await wallet()).customer.balance,600);assert.equal((await wallet()).ledger.length,1);
  const request=crypto.randomUUID(),bought=await Promise.all([purchase('go',20,request,{amount:0}),purchase('go',20,request,{amount:0})]);
  assert.ok(bought.every(r=>r.status===200));const order=bought[0].body.order;assert.equal(bought[1].body.order.orderNo,order.orderNo);assert.equal(order.amount,600);assert.equal(order.status,'completed');assert.deepEqual(order.delivery.split('\n'),cards);assert.deepEqual(await stock(),[0,99,2,2]);assert.equal((await wallet()).customer.balance,0);assert.equal((await wallet()).ledger.length,2);
  assert.equal((await call('/api/orders/'+order.orderNo,{cookie:outsider})).status,403);
  assert.equal((await call('/api/orders/'+order.orderNo+'/paid',{method:'POST',cookie,body:{}})).status,409);
  assert.equal((await call('/api/admin/orders/'+order.orderNo+'/cancel',{method:'POST',token:admin,body:{}})).status,409);
  const again=(await call('/api/customer/login',{method:'POST',body:{username:'wallet_user',password}})).cookie;
  assert.equal((await call('/api/orders/'+order.orderNo,{cookie:again})).body.order.delivery,order.delivery);
  assert.equal((await call('/api/customer/orders',{cookie:again})).body.orders.length,1);
  const add=(await call('/api/customer/topups',{method:'POST',cookie,body:{amount:100,payMethod:'wechat',requestId:crypto.randomUUID()}})).body.topup;
  await call('/api/customer/topups/'+add.topupNo+'/paid',{method:'POST',cookie,body:{payNote:'TXN_002'}});
  assert.equal((await confirm(add.topupNo)).status,409);assert.equal((await confirm(add.topupNo,'TXN_002')).status,200);
  const race=await Promise.all([purchase('race',1),purchase('race',1)]);assert.deepEqual(race.map(r=>r.status).sort(),[200,409]);assert.equal((await wallet()).customer.balance,40);assert.deepEqual(await stock(),[0,99,1,2]);
  const manual=(await purchase('manual',1)).body.order;assert.equal(manual.status,'paid');assert.equal(manual.delivery,'');assert.equal((await wallet()).customer.balance,30);
  const cancels=await Promise.all([1,2].map(()=>call('/api/admin/orders/'+manual.orderNo+'/cancel',{method:'POST',token:admin,body:{reason:'local-test'}})));assert.ok(cancels.every(r=>r.status===200));assert.equal((await wallet()).customer.balance,40);assert.deepEqual(await stock(),[0,99,1,2]);
  const ledgers=(await wallet()).ledger;assert.equal(new Set(ledgers.map(l=>l.id)).size,ledgers.length);assert.equal(ledgers.reduce((n,l)=>n+Math.round(l.amount*100),0),4000);
  const state=JSON.parse((await service.db.prepare('SELECT data FROM shop_state WHERE id=1').first()).data);
  const backup=prepareBackup({state,assets:[]});assert.deepEqual(JSON.parse(backup.data).customers,state.customers);assert.deepEqual(JSON.parse(backup.data).walletLedger,state.walletLedger);
  const bad=structuredClone(state);bad.customers[0].balanceCents++;assert.throws(()=>prepareBackup({state:bad,assets:[]}),/钱包备份/);
  const incomplete=structuredClone(state);delete incomplete.walletLedger;assert.throws(()=>prepareBackup({state:incomplete,assets:[]}),/钱包备份/);
  const publicData=JSON.stringify((await call('/api/shop')).body);assert.ok(!publicData.includes('PRIVATE'));assert.ok(!publicData.includes('balance'));
  assert.ok(!JSON.stringify(await wallet()).includes('passwordHash'));assert.ok(!JSON.stringify((await call('/api/admin/wallet',{token:admin})).body).includes('passwordHash'));
  const reset=await call('/api/customer/recover',{method:'POST',body:{username:'wallet_user',password:password+'NEW',recoveryCode:signup.body.recoveryCode}});assert.equal(reset.status,200);assert.equal((await call('/api/customer/wallet',{cookie})).status,401);cookie=reset.cookie;assert.equal((await wallet()).customer.balance,40);
  assert.equal((await call('/api/customer/recover',{method:'POST',body:{username:'wallet_user',password,recoveryCode:signup.body.recoveryCode}})).status,401);
  await call('/api/customer/logout',{method:'POST',cookie});assert.equal((await call('/api/customer/wallet',{cookie})).status,401);
});
