import fs from 'node:fs';
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { openDatabase } from '../database.mjs';
export function importState(input,filename,password){
  const state=input.state||input;
  if(!state.settings||!Array.isArray(state.products)||!Array.isArray(state.orders))throw new Error('备份缺少 settings/products/orders');
  if(!state.orders.every(o=>/^[a-f0-9]{64}$/i.test(o.orderKeyHash||'')))throw new Error('备份缺少完整订单查询密钥摘要，不能无损迁移');
  if(!/^[a-f0-9]{32,128}:\d{5,6}:[a-f0-9]{64}$/i.test(state.settings.adminPasswordHash||'')){
    if(!password||password.length<12||password.length>128)throw new Error('该备份不含管理员凭据，需在本机环境变量 INITIAL_ADMIN_PASSWORD 设置新的12至128位密码');
    const salt=randomBytes(16);state.settings.adminPasswordHash=`${salt.toString('hex')}:100000:${pbkdf2Sync(password,salt,100000,32,'sha256').toString('hex')}`;
  }
  const assets=input.assets||[];
  if(!Array.isArray(assets)||assets.some(a=>!/^[a-f0-9]{32}$/i.test(a.id)||!/^image\/(png|jpeg|gif|webp)$/.test(a.mime)||!/^[a-zA-Z0-9+/]+={0,2}$/.test(a.data)))throw new Error('图片备份格式不正确');
  const assetIds=new Set(assets.map(a=>a.id));
  const refs=[state.settings.shareImage,...state.products.map(p=>p.icon)].filter(v=>typeof v==='string'&&v.startsWith('/api/assets/')).map(v=>v.slice('/api/assets/'.length));
  if(refs.some(id=>!assetIds.has(id)))throw new Error('备份缺少正在使用的上传图片，请先取得完整图片备份');
  const data=JSON.stringify({settings:state.settings,products:state.products,orders:state.orders});
  if(Buffer.byteLength(data)>=1_800_000)throw new Error('备份数据超过当前版本容量，请先升级存储结构');
  const db=openDatabase(filename);
  try{
    if(db.sqlite.prepare('SELECT COUNT(*) AS n FROM shop_state').get().n||db.sqlite.prepare('SELECT COUNT(*) AS n FROM assets').get().n)throw new Error('目标数据库非空，已拒绝覆盖。请使用新的数据库文件路径');
    db.sqlite.exec('BEGIN IMMEDIATE');
    try{
      db.sqlite.prepare('INSERT INTO shop_state (id,data,version) VALUES (1,?,0)').run(data);
      for(const a of assets)db.sqlite.prepare('INSERT INTO assets (id,mime,data,created_at) VALUES (?,?,?,?)').run(a.id,a.mime,a.data,Number(a.created_at)||Date.now());
      db.sqlite.exec('COMMIT');
    }catch(error){db.sqlite.exec('ROLLBACK');throw error;}
    return {products:state.products.length,orders:state.orders.length,assets:assets.length};
  }finally{db.close();}
}
if(process.argv[1]?.endsWith('import-state.mjs')){
  try{
    const [, ,input,filename]=process.argv;if(!input||!filename)throw new Error('Usage: node tools/import-state.mjs PRIVATE_BACKUP.json NEW_DATABASE.sqlite');
    const result=importState(JSON.parse(fs.readFileSync(input,'utf8')),filename,process.env.INITIAL_ADMIN_PASSWORD);
    console.log(JSON.stringify(result));
  }catch(error){console.error(error.message);process.exitCode=1;}
}
