import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { openPostgres } from '../postgres.mjs';
import { prepareBackup } from './import-state.mjs';

export async function importPostgresBackup(db,input,password){
  const {state,assets,data}=prepareBackup(input,password);
  return db.transaction(async query=>{
    await query('LOCK TABLE shop_state, assets IN EXCLUSIVE MODE');
    const existing=await query('SELECT EXISTS(SELECT 1 FROM shop_state) OR EXISTS(SELECT 1 FROM assets) AS populated');
    if(existing.rows[0].populated)throw new Error('目标数据库非空，拒绝覆盖已有商品或订单');
    await query('INSERT INTO shop_state(id,data,version) VALUES(1,$1,0)',[data]);
    for(const a of assets)await query('INSERT INTO assets(id,mime,data,created_at) VALUES($1,$2,$3,$4)',[a.id,a.mime,a.data,Number(a.created_at)||Date.now()]);
    return {products:state.products.length,orders:state.orders.length,assets:assets.length};
  });
}

export async function exportPostgresBackup(db){
  return db.transaction(async query=>{
    await query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
    const row=(await query('SELECT data,version FROM shop_state WHERE id=1')).rows[0];
    if(!row)throw new Error('店铺数据尚未初始化');
    const assets=(await query('SELECT id,mime,data,created_at FROM assets')).rows;
    return {schemaVersion:1,exportedAt:new Date().toISOString(),version:row.version,state:JSON.parse(row.data),assets};
  });
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  let db;
  try{
    const [, ,action,filename]=process.argv;
    if(!['import','export'].includes(action)||!filename||!process.env.DATABASE_URL)throw new Error('设置DATABASE_URL后运行：node tools/postgres-backup.mjs import|export PRIVATE_FILE.json');
    db=await openPostgres(process.env.DATABASE_URL);
    if(action==='import')console.log(JSON.stringify(await importPostgresBackup(db,JSON.parse(await fs.readFile(filename,'utf8')),process.env.INITIAL_ADMIN_PASSWORD)));
    else {const backup=await exportPostgresBackup(db);await fs.writeFile(filename,JSON.stringify(backup),{flag:'wx',mode:0o600});console.log('私有备份已保存，请勿公开或提交到Git仓库');}
  }catch(error){console.error(error.code?'数据库操作失败：'+error.code:error.message);process.exitCode=1;}
  finally{await db?.close();}
}
