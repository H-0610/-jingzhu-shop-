import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { openPostgres } from '../postgres.mjs';
import { startShop } from '../server.mjs';

// Run only on the named, isolated QA branch. Never reset or delete cloud data.
let url = process.env.TEST_DATABASE_URL;
if(!url || !new URL(url).hostname.startsWith('ep-small-shape-aoy1w5za')) throw new Error('需要本次独立QA分支的TEST_DATABASE_URL');
const direct=new URL(url);direct.hostname=direct.hostname.replace('-pooler.','.');url=direct.href;
const password = randomBytes(24).toString('hex');
const checks=[]; const services=[];
const seed={settings:{shopName:'独立QA验证',wechatPayCode:'wxp://qa-not-real-payment'},products:[{id:'qa-product',name:'QA规格商品',enabled:true,skus:[
  {id:'qa-go',name:'Go',price:1,stock:24,inventoryType:'shared',cards:[],deliveryContent:'GO固定内容'},
  {id:'qa-plus',name:'Plus',price:2,stock:3,inventoryType:'cards',cards:['PLUS-A','PLUS-B','PLUS-C']}
]}],orders:[]};
const namespace='qa_'+Date.now();
const setup=await openPostgres(url);
await setup.prepare(`CREATE SCHEMA ${namespace}`).run();
await setup.close();
const scoped=new URL(url);scoped.searchParams.set('options',`-c search_path=${namespace}`);url=scoped.href;
const probe=await openPostgres(url);
assert.equal(await probe.prepare('SELECT id FROM shop_state WHERE id=1').first(),null,'QA数据库非空，拒绝覆盖；请创建新的测试分支');
await probe.close();
async function launch(){const service=await startShop({port:0,databaseUrl:url,password,seed});services.push(service);return service;}
async function call(service,route,{method='GET',body,token,key}={}){
  const r=await fetch(`http://127.0.0.1:${service.port}${route}`,{method,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{ }),...(key?{'x-order-key':key}:{})},body:body===undefined?undefined:JSON.stringify(body)});
  return {status:r.status,body:await r.json()};
}
try {
  const a=await launch(), b=await launch();
  const login=await call(a,'/api/admin/login',{method:'POST',body:{password}});assert.equal(login.status,200);const token=login.body.token;
  const snapshot=(await call(a,'/api/admin/data',{token})).body.products[0];
  const sales=await Promise.all(Array.from({length:8},(_,i)=>call(i%2?a:b,'/api/orders',{method:'POST',body:{skuId:'qa-plus',qty:1,payMethod:'wechat',contact:'qa-test',expectedPrice:2}})));
  const successful=sales.filter(r=>r.status===200);assert.equal(successful.length,3);assert.ok(sales.filter(r=>r.status!==200).every(r=>r.status===409));
  assert.deepEqual((await call(b,'/api/shop')).body.products[0].skus.map(s=>s.stock),[24,0]);checks.push('8 concurrent orders across 2 server instances: exactly 3 unique-stock sales, no overselling');
  assert.equal((await call(a,'/api/admin/products',{method:'POST',token,body:{...snapshot,expectedRevision:snapshot.revision||0}})).status,409);checks.push('stale admin save cannot restore sold inventory');
  const go=(await call(b,'/api/orders',{method:'POST',body:{skuId:'qa-go',qty:2,payMethod:'wechat',contact:'qa-test'}})).body.order;
  assert.ok(go);assert.equal((await call(a,`/api/orders/${go.orderNo}`,{key:go.orderKey})).body.order.delivery,'');
  const deliveries=[];
  for(const order of [...successful.map(r=>r.body.order),go]){
    assert.equal((await call(b,`/api/orders/${order.orderNo}/paid`,{method:'POST',key:order.orderKey,body:{}})).status,200);
    assert.equal((await call(a,`/api/admin/orders/${order.orderNo}/confirm`,{method:'POST',token,body:{}})).status,200);
    const duplicate=await call(b,`/api/admin/orders/${order.orderNo}/confirm`,{method:'POST',token,body:{}});assert.equal(duplicate.status,200);
    deliveries.push((await call(b,`/api/orders/${order.orderNo}`,{key:order.orderKey})).body.order.delivery);
  }
  assert.deepEqual(deliveries.slice(0,3).sort(),['PLUS-A','PLUS-B','PLUS-C']);assert.equal(deliveries[3],'GO固定内容');checks.push('SKU delivery is isolated, hidden before receipt confirmation, and confirmation is idempotent');
  await a.close();await b.close();services.length=0;
  const restarted=await launch();
  assert.equal((await call(restarted,`/api/orders/${go.orderNo}`,{key:go.orderKey})).body.order.delivery,'GO固定内容');
  assert.deepEqual((await call(restarted,'/api/shop')).body.products[0].skus.map(s=>s.stock),[22,0]);
  assert.equal((await call(restarted,`/api/orders/${go.orderNo}`,{key:'0'.repeat(64)})).status,403);checks.push('server restart preserves inventory, deliveries and protected order lookup');
  const cancel=(await call(restarted,'/api/orders',{method:'POST',body:{skuId:'qa-go',qty:1,payMethod:'wechat',contact:'qa-test'}})).body.order;
  for(let i=0;i<2;i++)assert.equal((await call(restarted,`/api/admin/orders/${cancel.orderNo}/cancel`,{method:'POST',token,body:{}})).status,200);
  assert.equal((await call(restarted,'/api/shop')).body.products[0].skus[0].stock,22);checks.push('cancel returns reserved inventory exactly once');
  console.log(JSON.stringify({ok:true,checks},null,2));
} finally {for(const service of services)await service.close();}
