CREATE TABLE IF NOT EXISTS admin_sessions (
  token_hash text PRIMARY KEY,
  expires_at bigint NOT NULL
);
CREATE TABLE IF NOT EXISTS assets (
  id text PRIMARY KEY,
  mime text NOT NULL,
  data text NOT NULL,
  created_at bigint NOT NULL
);
CREATE TABLE IF NOT EXISTS rate_limits (
  key text PRIMARY KEY,
  count integer NOT NULL,
  reset_at bigint NOT NULL
);
CREATE TABLE IF NOT EXISTS shop_state (
  id integer PRIMARY KEY,
  data text NOT NULL,
  version integer NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS customer_sessions (
  token_hash text PRIMARY KEY,
  customer_id text NOT NULL,
  credential_hash text NOT NULL,
  expires_at bigint NOT NULL
);
