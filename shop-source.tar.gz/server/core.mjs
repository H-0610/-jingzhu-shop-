const EXPIRY_MS = 30 * 60 * 1000;
const SESSION_MS = 12 * 60 * 60 * 1000;
const MAX_STATE_BYTES = 1_800_000;
const encoder = new TextEncoder();
const clone = (value) => JSON.parse(JSON.stringify(value));
const hex = (bytes) => Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
const random = (length = 32) => hex(crypto.getRandomValues(new Uint8Array(length)));
const digest = async (value) => hex(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(value))));
const validId = (value) => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(value);
class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
function assert(condition, status, message) { if (!condition) throw new ApiError(status, message); }
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  let mismatch = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) mismatch |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return mismatch === 0;
}
function reply(data, status = 200, headers = {}) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers } });
}
function credentialValid(encoded) {
  const parts = String(encoded || '').split(':');
  return parts.length === 3 && /^[a-f0-9]{32,128}$/i.test(parts[0]) && Number(parts[1]) >= 10_000 && Number(parts[1]) <= 100_000 && /^[a-f0-9]{64}$/i.test(parts[2]);
}
async function derivePassword(password, encoded) {
  if (!credentialValid(encoded)) return '';
  const [salt, rounds] = encoded.split(':');
  const material = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const saltBytes = Uint8Array.from(salt.match(/../g), (part) => parseInt(part, 16));
  return hex(new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: saltBytes, iterations: Number(rounds), hash: 'SHA-256' }, material, 256)));
}
async function makePassword(password) {
  const prefix = `${random(16)}:100000:`;
  return prefix + await derivePassword(password, prefix + '0'.repeat(64));
}
function validPayment(kind, value) {
  if (!value || typeof value !== 'string' || value.length > 512 || /\s/.test(value)) return false;
  if (kind === 'wechat') return /^wxp:\/\/[^\s]{4,500}$/i.test(value);
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === 'qr.alipay.com' && !url.username && !url.password && !url.port && url.pathname !== '/';
  } catch { return false; }
}
function paymentFor(settings, kind) {
  const code = settings[kind === 'wechat' ? 'wechatPayCode' : 'alipayPayCode'];
  return validPayment(kind, code) ? { code } : null;
}
function stockOf(sku) { return sku.inventoryType === 'cards' ? sku.cards.length : sku.stock; }
function touchProduct(product) { product.revision = (product.revision || 0) + 1; }
function findSku(state, id) {
  for (const product of state.products) {
    const sku = product.skus.find((item) => item.id === id);
    if (sku) return { product, sku };
  }
  return null;
}
function publicSettings(settings) {
  const { shopName, shopSubtitle, notice, contact, shareDesc, shareImage } = settings;
  return { shopName, shopSubtitle, notice, contact, shareDesc, shareImage };
}
function adminSettings(settings) {
  const { adminPasswordHash, adminSalt, adminHash, ...visible } = settings;
  return { ...visible, mustChangePwd: false };
}
function publicOrder(order, key) {
  return {
    orderNo: order.orderNo, orderKey: key, productName: order.productName,
    skuName: order.skuName, qty: order.qty, price: order.price, amount: order.amount,
    payMethod: order.payMethod, status: order.status, createdAt: order.createdAt,
    paidAt: order.paidAt, completedAt: order.completedAt,
    expireAt: new Date(Date.parse(order.createdAt) + EXPIRY_MS).toISOString(),
    delivery: order.status === 'completed' ? order.delivery : '', closeReason: order.closeReason || '',
    payment: order.status === 'pending' ? order.payment : null,
  };
}
function releaseReservation(state, order) {
  if (order.reservationReleased || order.status === 'completed') return;
  const found = findSku(state, order.skuId);
  if (found) {
    if (order.inventoryType === 'cards') found.sku.cards.unshift(...(order.reservedCards || []));
    else found.sku.stock += order.qty;
    touchProduct(found.product);
  }
  order.reservationReleased = true;
  order.reservedCards = [];
  order.reservedContent = "";
}
function expire(state, timestamp) {
  for (const order of state.orders) {
    if (order.status === 'pending' && Date.parse(order.createdAt) + EXPIRY_MS <= timestamp) {
      releaseReservation(state, order);
      order.status = 'closed'; order.closeReason = '超时未付款';
    }
  }
}
function priceCents(value) {
  const parsed = Number(value);
  assert(Number.isFinite(parsed) && parsed >= 0 && parsed <= 1_000_000, 400, '商品价格不正确');
  const cents = Math.round(parsed * 100);
  assert(Math.abs(parsed * 100 - cents) < 0.000001, 400, '价格最多保留两位小数');
  return cents;
}
function cleanSku(input, existing) {
  const name = String(input.name || '').trim();
  assert(name && name.length <= 100, 400, '请填写正确的规格名称');
  const stock = Number(input.stock ?? 0);
  assert(Number.isSafeInteger(stock) && stock >= 0 && stock <= 1_000_000, 400, '库存必须是非负整数');
  const cards = (Array.isArray(input.cards) ? input.cards : String(input.cards || '').split('\n')).map((item) => String(item).trim()).filter(Boolean);
  assert(cards.length <= 10_000 && cards.every((item) => item.length <= 4000), 400, '发货内容过多或过长');
  const inventoryType = input.inventoryType ?? (cards.length ? 'cards' : (existing?.inventoryType || 'manual'));
  assert(['cards', 'shared', 'manual'].includes(inventoryType), 400, '请选择正确的发货方式');
  const deliveryContent = String(input.deliveryContent || '').trim();
  assert(deliveryContent.length <= 10000, 400, '固定发货内容不能超过 10000 字');
  assert(inventoryType !== 'shared' || deliveryContent, 400, '请填写该规格的固定发货内容');
  assert(inventoryType !== 'cards' || new Set(cards).size === cards.length, 400, '独立发货内容有重复行，请删除重复内容');
  const id = input.id || `s_${random(8)}`;
  assert(validId(id), 400, '规格编号不正确');
  return { id, name, price: priceCents(input.price) / 100,
    stock: inventoryType === 'cards' ? cards.length : stock,
    cards: inventoryType === 'cards' ? cards : [], inventoryType,
    deliveryContent: inventoryType === 'shared' ? deliveryContent : '' };
}
async function readJson(request, maxBytes = 3_000_000) {
  assert(Number(request.headers.get('content-length') || 0) <= maxBytes, 413, '请求内容过大');
  const text = await request.text();
  assert(encoder.encode(text).length <= maxBytes, 413, '请求内容过大');
  try {
    const body = text ? JSON.parse(text) : {};
    assert(body && typeof body === 'object' && !Array.isArray(body), 400, '请求格式不正确');
    return body;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(400, '请求格式不正确');
  }
}
export function createShopApi({ db, seed, initialPasswordHash = '', now = () => Date.now() }) {
  function seedState() {
    const state = clone(seed);
    state.orders = []; state.settings ||= {}; state.products ||= [];
    delete state.settings.adminSalt; delete state.settings.adminHash;
    state.settings.adminPasswordHash = credentialValid(initialPasswordHash) ? initialPasswordHash : '';
    state.settings.mustChangePwd = false;
    state.settings.shareDesc ||= '自助选购，扫码下单'; state.settings.shareImage ||= '/share-cover.svg';
    for (const product of state.products) for (const sku of product.skus) {
      sku.cards ||= []; sku.inventoryType ||= sku.cards.length ? 'cards' : 'manual'; sku.stock = Math.max(0, Number(sku.stock) || 0);
    }
    return state;
  }
  async function loadState() {
    let row = await db.prepare('SELECT data, version FROM shop_state WHERE id = 1').first();
    if (!row) {
      await db.prepare('INSERT OR IGNORE INTO shop_state (id, data, version) VALUES (1, ?, 0)').bind(JSON.stringify(seedState())).run();
      row = await db.prepare('SELECT data, version FROM shop_state WHERE id = 1').first();
    }
    assert(row, 503, '店铺正在初始化，请稍后重试');
    return { state: JSON.parse(row.data), version: row.version, raw: row.data };
  }
  async function mutate(operation) {
    for (let attempt = 0; attempt < 24; attempt++) {
      const { state, version, raw } = await loadState();
      expire(state, now());
      const result = operation(state);
      const next = JSON.stringify(state);
      if (next === raw) return result;
      assert(encoder.encode(next).length < MAX_STATE_BYTES, 409, '店铺数据容量接近上限，请联系管理员归档');
      const saved = await db.prepare('UPDATE shop_state SET data = ?, version = version + 1 WHERE id = 1 AND version = ?').bind(next, version).run();
      if (saved.meta?.changes === 1 || saved.changes === 1) return result;
    }
    throw new ApiError(409, '当前下单人数较多，请稍后重试');
  }
  async function limit(request, action, maximum, windowMs) {
    const ip = request.headers.get('cf-connecting-ip') || 'unknown';
    const timestamp = now();
    const row = await db.prepare('INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN rate_limits.reset_at <= ? THEN 1 ELSE rate_limits.count + 1 END, reset_at = CASE WHEN rate_limits.reset_at <= ? THEN ? ELSE rate_limits.reset_at END RETURNING count').bind(`${action}:${ip.slice(0, 100)}`, timestamp + windowMs, timestamp, timestamp, timestamp + windowMs).first();
    assert(row && row.count <= maximum, 429, '操作过于频繁，请稍后再试');
  }
  async function authorizeOrder(request, state, orderNo) {
    const key = request.headers.get('x-order-key') || '';
    assert(/^[a-f0-9]{64}$/i.test(key), 403, '请输入正确的订单号和查询密钥');
    const hashed = await digest(key);
    const order = state.orders.find((item) => item.orderNo === orderNo);
    assert(order && safeEqual(order.orderKeyHash, hashed), 403, '订单号或查询密钥不正确');
    return { order, key };
  }
  async function adminAuth(request) {
    const token = (request.headers.get('authorization') || '').match(/^Bearer ([a-f0-9]{64})$/i)?.[1];
    assert(token, 401, '未登录或登录已过期');
    const { state } = await loadState();
    const credential = state.settings.adminPasswordHash;
    const tokenHash = await digest(`${token}:${credential}`);
    const session = await db.prepare('SELECT expires_at FROM admin_sessions WHERE token_hash = ?').bind(tokenHash).first();
    assert(session && session.expires_at > now(), 401, '未登录或登录已过期');
    return { state, credential, tokenHash };
  }
  function protectedMutation(auth, operation) {
    return mutate((state) => { assert(safeEqual(state.settings.adminPasswordHash, auth.credential), 401, '密码已更新，请重新登录'); return operation(state); });
  }
  async function dispatch(request) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/$/, '');
    const method = request.method;
    let match;
    if (method === 'GET' && (match = path.match(/^\/api\/assets\/([a-f0-9]{32})$/))) {
      const asset = await db.prepare('SELECT mime, data FROM assets WHERE id = ?').bind(match[1]).first();
      assert(asset, 404, '图片不存在');
      return new Response(Uint8Array.from(atob(asset.data), (ch) => ch.charCodeAt(0)), { headers: { 'Content-Type': asset.mime, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
    }
    if (method === 'GET' && path === '/api/shop') {
      return reply(await mutate((state) => ({
        ...publicSettings(state.settings), expireMin: 30,
        pay: { wechat: !!paymentFor(state.settings, 'wechat'), alipay: !!paymentFor(state.settings, 'alipay') },
        products: state.products.filter((product) => product.enabled !== false).sort((a, b) => (a.sort || 0) - (b.sort || 0)).map((product) => ({
          id: product.id, name: product.name, icon: product.icon, tag: product.tag,
          skus: product.skus.map((sku) => ({ id: sku.id, name: sku.name, price: sku.price, stock: stockOf(sku) })),
        })),
      })));
    }
    if (method === 'POST' && path === '/api/orders') {
      await limit(request, 'orders', 15, 10 * 60 * 1000);
      const body = await readJson(request, 10_000);
      const qty = Number(body.qty);
      assert(Number.isInteger(qty) && qty >= 1 && qty <= 999, 400, '购买数量不正确');
      assert(['wechat', 'alipay'].includes(body.payMethod), 400, '请选择支付方式');
      const contact = String(body.contact || '').trim();
      assert(contact && contact.length <= 100, 400, '请填写正确的联系方式');
      const key = random(); const keyHash = await digest(key); const timestamp = now();
      const numberPart = crypto.getRandomValues(new Uint32Array(1))[0] % 100_000_000;
      const orderNo = new Date(timestamp + 8 * 3600 * 1000).toISOString().slice(0, 19).replace(/\D/g, '') + String(numberPart).padStart(8, '0');
      const order = await mutate((state) => {
        const found = findSku(state, body.skuId);
        assert(found && found.product.enabled !== false, 400, '商品不存在或已下架');
        assert(stockOf(found.sku) >= qty, 409, '库存不足，请刷新商品列表');
        const payment = paymentFor(state.settings, body.payMethod);
        assert(payment, 400, '该支付方式暂不可用');
        const cents = priceCents(found.sku.price);
        if (body.expectedPrice !== undefined) assert(priceCents(body.expectedPrice) === cents, 409, '商品价格已更新，请核对最新价格后重新下单');
        const reservedCards = found.sku.inventoryType === 'cards' ? found.sku.cards.splice(0, qty) : [];
        if (found.sku.inventoryType !== 'cards') found.sku.stock -= qty;
        touchProduct(found.product);
        const entry = {
          orderNo, orderKeyHash: keyHash, productId: found.product.id, productName: found.product.name,
          skuId: found.sku.id, skuName: found.sku.name, qty, price: cents / 100, amount: cents * qty / 100,
          payMethod: body.payMethod, payment, contact, remark: String(body.remark || '').trim().slice(0, 300),
          payNote: '', status: 'pending', delivery: '', createdAt: new Date(timestamp).toISOString(),
          reservedCards, inventoryType: found.sku.inventoryType, reservationReleased: false,
          reservedContent: found.sku.inventoryType === 'shared' ? found.sku.deliveryContent : '',
        };
        assert(!state.orders.some((item) => item.orderNo === orderNo), 409, '请重新提交订单');
        state.orders.unshift(entry); return publicOrder(entry, key);
      });
      return reply({ order });
    }
    if ((method === 'GET' && (path === '/api/orders/query' || /^\/api\/orders\/\d+$/.test(path))) || (method === 'POST' && /^\/api\/orders\/\d+\/paid$/.test(path))) {
      await limit(request, method === 'GET' ? 'query' : 'paid', method === 'GET' ? 120 : 20, 60_000);
      const orderNo = path === '/api/orders/query' ? url.searchParams.get('kw') || '' : path.split('/')[3];
      assert(/^\d{18,28}$/.test(orderNo), 403, '请输入正确的订单号和查询密钥');
      const { key } = await authorizeOrder(request, (await loadState()).state, orderNo);
      const body = method === 'POST' ? await readJson(request, 5000) : {};
      const order = await mutate((state) => {
        const entry = state.orders.find((item) => item.orderNo === orderNo);
        assert(entry, 403, '订单号或查询密钥不正确');
        if (method === 'POST') {
          assert(entry.status === 'pending' || entry.status === 'paid', 409, '订单状态已变更');
          if (entry.status === 'pending') {
            entry.status = 'paid'; entry.paidAt = new Date(now()).toISOString(); entry.payNote = String(body.payNote || '').trim().slice(0, 200);
          }
        }
        return publicOrder(entry, key);
      });
      return reply(path === '/api/orders/query' ? { orders: [order] } : { order });
    }
    if (method === 'POST' && path === '/api/admin/login') {
      await limit(request, 'login', 8, 10 * 60 * 1000);
      const body = await readJson(request, 5000);
      const { state } = await loadState();
      const encoded = state.settings.adminPasswordHash;
      assert(credentialValid(encoded), 503, '管理入口尚未配置完成');
      assert(typeof body.password === 'string' && body.password.length <= 128, 401, '密码错误');
      assert(safeEqual(await derivePassword(body.password, encoded), encoded.split(':')[2]), 401, '密码错误');
      const token = random();
      await db.prepare('DELETE FROM admin_sessions WHERE expires_at <= ?').bind(now()).run();
      await db.prepare('INSERT INTO admin_sessions (token_hash, expires_at) VALUES (?, ?)').bind(await digest(`${token}:${encoded}`), now() + SESSION_MS).run();
      return reply({ token, defaultPassword: false });
    }
    if (path.startsWith('/api/admin/')) {
      const auth = await adminAuth(request);
      if (method === 'POST' && path === '/api/admin/logout') {
        await db.prepare('DELETE FROM admin_sessions WHERE token_hash = ?').bind(auth.tokenHash).run();
        return reply({ ok: true });
      }
      if (method === 'GET' && path === '/api/admin/data') {
        return reply(await protectedMutation(auth, (state) => ({
          settings: adminSettings(state.settings), products: state.products,
          orders: state.orders.slice(0, 1000).map(({ orderKeyHash, reservedCards, reservedContent, deliveryItems, payment, ...order }) => ({ ...order, hasReservedCards: !!reservedCards?.length, hasAutomaticDelivery: !!(reservedCards?.length || reservedContent) })),
        })));
      }
      if (method === 'GET' && path === '/api/admin/export') {
        const data = await protectedMutation(auth, (state) => ({
          schemaVersion: 1, exportedAt: new Date(now()).toISOString(), settings: adminSettings(state.settings), products: state.products, orders: state.orders,
        }));
        return reply(data, 200, { 'Content-Disposition': `attachment; filename="shop-backup-${new Date(now()).toISOString().slice(0, 10)}.json"` });
      }
      if (method === 'GET' && path === '/api/admin/stats') {
        return reply(await protectedMutation(auth, (state) => {
          const day = new Date(now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
          const done = state.orders.filter((order) => order.status === 'completed');
          const today = done.filter((order) => new Date(Date.parse(order.completedAt) + 8 * 3600 * 1000).toISOString().startsWith(day));
          const total = (orders) => orders.reduce((sum, order) => sum + Math.round(order.amount * 100), 0) / 100;
          return { totalOrders: state.orders.length, waitConfirm: state.orders.filter((order) => order.status === 'paid').length, totalSales: total(done), todaySales: total(today), todayOrders: today.length };
        }));
      }
      if (method === 'PUT' && path === '/api/admin/settings') {
        const body = await readJson(request, 25_000);
        let passwordHash;
        if (body.newPassword) {
          assert(typeof body.newPassword === 'string' && body.newPassword.length >= 12 && body.newPassword.length <= 128, 400, '新密码需为 12–128 位');
          passwordHash = await makePassword(body.newPassword);
        }
        const changed = await protectedMutation(auth, (state) => {
          for (const field of ['shopName', 'shopSubtitle', 'notice', 'contact', 'shareDesc', 'shareImage']) {
            if (typeof body[field] === 'string') {
              assert(body[field].length <= (field === 'notice' ? 4000 : 2000), 400, '设置内容过长');
              state.settings[field] = body[field].trim();
            }
          }
          for (const [kind, field] of [['wechat', 'wechatPayCode'], ['alipay', 'alipayPayCode']]) {
            if (typeof body[field] === 'string') {
              const value = body[field].trim();
              assert(!value || validPayment(kind, value), 400, '收款链接不正确，请上传对应平台的收款码');
              state.settings[field] = value;
            }
          }
          if (passwordHash) state.settings.adminPasswordHash = passwordHash;
          return { ok: true, mustChangePwd: false, reauthenticate: !!passwordHash, needLogin: !!passwordHash };
        });
        if (passwordHash) await db.prepare('DELETE FROM admin_sessions').run();
        return reply(changed);
      }
      if (method === 'POST' && path === '/api/admin/upload') {
        const body = await readJson(request);
        const parts = String(body.dataUrl || '').match(/^data:image\/(png|jpe?g|gif|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
        assert(parts, 400, '仅支持 PNG、JPEG、GIF、WebP 图片');
        let bytes;
        try { bytes = Uint8Array.from(atob(parts[2]), (ch) => ch.charCodeAt(0)); } catch { throw new ApiError(400, '图片格式不正确'); }
        assert(bytes.length > 12 && bytes.length <= 1024 * 1024, 400, '图片不能超过 1MB');
        const kind = parts[1] === 'jpg' ? 'jpeg' : parts[1];
        const ascii = (start, end) => String.fromCharCode(...bytes.slice(start, end));
        const magic = kind === 'png' ? hex(bytes.slice(0, 8)) === '89504e470d0a1a0a' : kind === 'jpeg' ? hex(bytes.slice(0, 3)) === 'ffd8ff' : kind === 'gif' ? /^GIF8[79]a$/.test(ascii(0, 6)) : ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP';
        assert(magic, 400, '图片内容与格式不符');
        const id = random(16); const assetUrl = `/api/assets/${id}`;
        await db.prepare('INSERT INTO assets (id, mime, data, created_at) VALUES (?, ?, ?, ?)').bind(id, `image/${kind}`, parts[2], now()).run();
        if (body.target === 'shareImage') await protectedMutation(auth, (state) => { state.settings.shareImage = assetUrl; });
        return reply({ url: assetUrl });
      }
      if (method === 'POST' && path === '/api/admin/products') {
        const body = await readJson(request, 500_000);
        const product = await protectedMutation(auth, (state) => {
          const name = String(body.name || '').trim();
          assert(name && name.length <= 100, 400, '请填写正确的商品名称');
          assert(Array.isArray(body.skus) && body.skus.length > 0 && body.skus.length <= 100, 400, '请填写 1–100 个规格');
          const existing = body.id ? state.products.find((item) => item.id === body.id) : null;
          assert(!body.id || existing, 404, '商品不存在');
          assert(!existing || body.expectedRevision === (existing.revision || 0), 409, '商品或库存已变化，请关闭编辑窗口后重新打开，再保存修改');
          const skus = body.skus.map((input) => cleanSku(input, existing?.skus.find((sku) => sku.id === input.id)));
          const ids = skus.map((sku) => sku.id);
          assert(new Set(ids).size === ids.length && !state.products.some((item) => item.id !== existing?.id && item.skus.some((sku) => ids.includes(sku.id))), 400, '规格编号重复');
          if (existing) for (const old of existing.skus) {
            const held = state.orders.some(order => order.skuId === old.id && ['pending', 'paid'].includes(order.status));
            const next = skus.find(sku => sku.id === old.id);
            assert(!held || (next && next.inventoryType === old.inventoryType), 409, '该规格有待处理订单，暂不能删除或切换发货方式；可调整剩余库存和新订单内容');
          }
          for (const sku of skus.filter(item => item.inventoryType === 'cards')) {
            const allocated = new Set(state.orders.filter(order => order.skuId === sku.id && order.inventoryType === 'cards' && order.status !== 'closed')
              .flatMap(order => order.status === 'completed' ? (order.deliveryItems || String(order.delivery || '').split('\n')) : (order.reservedCards || [])));
            assert(!sku.cards.some(card => allocated.has(card)), 409, '该规格的内容包含已预留或已发出的内容，请勿重复补入');
          }
          const entry = { id: existing?.id || `p_${random(8)}`, revision: (existing?.revision || 0) + 1, name, icon: String(body.icon || '📦').slice(0, 2000), tag: String(body.tag || '').slice(0, 40), sort: Number.isFinite(Number(body.sort)) ? Number(body.sort) : 0, enabled: body.enabled !== false, skus };
          if (existing) Object.assign(existing, entry); else state.products.push(entry);
          return entry;
        });
        return reply({ product });
      }
      if (method === 'PATCH' && (match = path.match(/^\/api\/admin\/products\/([\w-]+)\/visibility$/))) {
        const body = await readJson(request, 1000);
        assert(typeof body.enabled === 'boolean', 400, '请选择商品上下架状态');
        const product = await protectedMutation(auth, state => {
          const entry = state.products.find(item => item.id === match[1]);
          assert(entry, 404, '商品不存在');
          entry.enabled = body.enabled;
          touchProduct(entry);
          return {id:entry.id,enabled:entry.enabled};
        });
        return reply({product});
      }
      if (method === 'DELETE' && (match = path.match(/^\/api\/admin\/products\/([\w-]+)$/))) {
        await protectedMutation(auth, (state) => {
          assert(!state.orders.some((order) => order.productId === match[1] && ['pending', 'paid'].includes(order.status)), 409, '该商品有待处理订单，暂不能删除');
          state.products = state.products.filter((product) => product.id !== match[1]);
        });
        return reply({ ok: true });
      }
      if (method === 'POST' && (match = path.match(/^\/api\/admin\/orders\/(\d+)\/(confirm|cancel)$/))) {
        const body = await readJson(request, 15_000);
        const order = await protectedMutation(auth, (state) => {
          const entry = state.orders.find((item) => item.orderNo === match[1]);
          assert(entry, 404, '订单不存在');
          if (match[2] === 'cancel') {
            assert(entry.status !== 'completed', 409, '已完成订单不能关闭');
            if (entry.status !== 'closed') {
              releaseReservation(state, entry); entry.status = 'closed'; entry.closeReason = String(body.reason || '商家关闭').slice(0, 100);
            }
          } else if (entry.status !== 'completed') {
            assert(entry.status === 'paid', 409, '请等待客户提交付款信息，并核对实际到账后再确认');
            assert(!entry.reservationReleased && findSku(state, entry.skuId), 409, '库存预留已失效，请联系管理员');
            let delivery = String(body.delivery || '').trim().slice(0, 10_000);
            if (entry.inventoryType === 'cards') {
              assert(entry.reservedCards?.length === entry.qty, 409, '预留发货内容不足，请联系管理员');
              delivery = [delivery, ...entry.reservedCards].filter(Boolean).join('\n');
              entry.deliveryItems = [...entry.reservedCards];
            }
            if (entry.inventoryType === 'shared') {
              assert(entry.reservedContent, 409, '该订单未预留固定发货内容，请联系管理员');
              delivery = [delivery, entry.reservedContent].filter(Boolean).join('\n');
            }
            entry.reservedContent = '';
            entry.delivery = delivery || '商家已确认收款，订单已完成。'; entry.status = 'completed'; entry.completedAt = new Date(now()).toISOString(); entry.reservedCards = [];
          }
          const { orderKeyHash, reservedCards, payment, ...visible } = entry;
          return visible;
        });
        return reply({ order });
      }
    }
    throw new ApiError(404, '接口不存在');
  }
  return {
    async handle(request) {
      try { return await dispatch(request); }
      catch (error) { return reply({ error: error instanceof ApiError ? error.message : '店铺服务暂时不可用，请稍后重试' }, error instanceof ApiError ? error.status : 503); }
    },
    async getPublicSettings() { return mutate((state) => publicSettings(state.settings)); },
  };
}

