// Money movements live in the same versioned state transaction as orders and stock.
export function initializeWallet(state) {
  state.customers ||= []; state.topups ||= []; state.walletLedger ||= [];
}
export function createWallet({db, loadState, mutate, protectedMutation, limit, readJson, assert, reply, random, digest, safeEqual, makePassword, derivePassword, paymentFor, publicOrder, now}) {
  const sessionMs = 7 * 86400000;
  const stamp = () => new Date(now()).toISOString();
  const summary = u => ({id:u.id, username:u.username, balance:u.balanceCents / 100, totalTopup:u.topupCents / 100, totalSpent:u.spentCents / 100, totalRefund:u.refundCents / 100, createdAt:u.createdAt});
  const topupView = t => {const {payment, ...visible}=t;return {...visible,payment:t.status==='pending'?payment:null};};
  const csrf = request => {
    assert(request.headers.get('x-wallet-request') === '1',403,'请通过店铺页面操作');
    const origin=request.headers.get('origin');
    assert(!origin || origin === new URL(request.url).origin,403,'请求来源不正确');
  };
  const tokenOf = request => (request.headers.get('cookie') || '').match(/(?:^|;\s*)shop_customer=([a-f0-9]{64})(?:;|$)/)?.[1];
  const cookie = (request, token, age=sessionMs/1000) => `shop_customer=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${new URL(request.url).protocol==='https:'?'; Secure':''}`;
  function username(value) {const name=String(value || '').trim().toLowerCase();assert(/^[a-z0-9][a-z0-9_-]{3,39}$/.test(name),400,'账号需为4–40位字母、数字、下划线或短横线');return name;}
  function password(value) {assert(typeof value==='string' && value.length>=12 && value.length<=128,400,'密码需为12–128位');return value;}
  function requestId(value) {assert(typeof value==='string' && /^[a-zA-Z0-9_-]{16,80}$/.test(value),400,'请刷新页面后重试');return value;}
  function cents(value) {assert(typeof value==='number' && Number.isFinite(value) && value>=1 && value<=10000 && Math.abs(value*100-Math.round(value*100))<0.000001,400,'单次充值金额为1–10000元，最多两位小数');return Math.round(value*100);}
  function userIn(state, auth) {const u=state.customers.find(x=>x.id===auth.user.id);assert(u && safeEqual(u.passwordHash,auth.user.passwordHash),401,'登录已过期，请重新登录');return u;}
  async function auth(request) {
    const token=tokenOf(request); assert(token,401,'请先登录客户账号');
    const tokenHash=await digest(token);
    const session=await db.prepare('SELECT customer_id, credential_hash, expires_at FROM customer_sessions WHERE token_hash = ?').bind(tokenHash).first();
    assert(session && session.expires_at>now(),401,'登录已过期，请重新登录');
    const {state}=await loadState();const user=state.customers.find(u=>u.id===session.customer_id);
    assert(user && safeEqual(await digest(user.passwordHash),session.credential_hash),401,'登录已过期，请重新登录');
    return {user,tokenHash};
  }
  async function signIn(request, user, extra={}) {
    const token=random();
    await db.prepare('DELETE FROM customer_sessions WHERE expires_at <= ?').bind(now()).run();
    await db.prepare('INSERT INTO customer_sessions (token_hash, customer_id, credential_hash, expires_at) VALUES (?, ?, ?, ?)').bind(await digest(token),user.id,await digest(user.passwordHash),now()+sessionMs).run();
    return reply({customer:summary(user),...extra},200,{'Set-Cookie':cookie(request,token)});
  }
  function move(state,u,type,amountCents,relatedNo,remark) {
    assert(Number.isSafeInteger(amountCents) && Number.isSafeInteger(u.balanceCents),409,'余额记录异常，请联系客服');
    const id=`${type}:${relatedNo}`;
    assert(!state.walletLedger.some(l=>l.id===id),409,'该笔流水已处理');
    const balance=u.balanceCents+amountCents;
    assert(balance>=0,409,'钱包余额不足，请先充值或选择扫码付款');
    assert(Number.isSafeInteger(balance) && balance<=100_000_000,409,'余额已达账户上限，请联系客服');
    u.balanceCents=balance;
    if(type==='topup')u.topupCents+=amountCents;
    if(type==='purchase')u.spentCents-=amountCents;
    if(type==='refund')u.refundCents+=amountCents;
    state.walletLedger.unshift({id,customerId:u.id,type,amount:amountCents/100,balance:balance/100,relatedNo,remark,createdAt:stamp()});
  }
  const spend=(state,auth,order)=>{const u=userIn(state,auth);move(state,u,'purchase',-Math.round(order.amount*100),order.orderNo,`${order.productName} / ${order.skuName} × ${order.qty}`);};
  const refund=(state,order)=>{
    if(order.payMethod!=='wallet' || order.walletRefundedAt)return;
    const u=state.customers.find(x=>x.id===order.customerId);assert(u,409,'客户账户不存在');
    move(state,u,'refund',Math.round(order.amount*100),order.orderNo,'关闭订单，退回余额');order.walletRefundedAt=stamp();
  };
  async function publicRoute(request,path,method) {
    if(!path.startsWith('/api/customer/'))return null;
    if(method!=='GET')csrf(request);
    if(method==='POST' && ['/api/customer/register','/api/customer/login','/api/customer/recover'].includes(path)) {
      await limit(request,'customer-auth',12,10*60000);
      const body=await readJson(request,5000);const name=username(body.username);
      await limit(request,`customer-account-${await digest(name)}`,12,10*60000);
      if(path.endsWith('/register')) {
        await limit(request,'customer-register',5,3600000);
        const hash=await makePassword(password(body.password),600000), recoveryCode=random(), recoveryHash=await digest(recoveryCode), id='c_'+random(12);
        const user=await mutate(state=>{
          assert(!state.customers.some(u=>u.username===name),409,'该账号已被使用，请更换账号或登录');
          const u={id,username:name,passwordHash:hash,recoveryHash,balanceCents:0,topupCents:0,spentCents:0,refundCents:0,createdAt:stamp()};state.customers.push(u);return u;
        });
        return signIn(request,user,{recoveryCode});
      }
      const {state}=await loadState(); const existing=state.customers.find(u=>u.username===name);
      if(path.endsWith('/recover')) {
        const code=String(body.recoveryCode || '').trim();
        assert(existing && /^[a-f0-9]{64}$/.test(code) && safeEqual(await digest(code),existing.recoveryHash),401,'账号或恢复码不正确');
        const hash=await makePassword(password(body.password),600000), newCode=random(), recoveryHash=await digest(newCode);
        const user=await mutate(s=>{const u=s.customers.find(x=>x.id===existing.id);assert(u && safeEqual(u.recoveryHash,existing.recoveryHash),409,'恢复码已使用，请重新操作');u.passwordHash=hash;u.recoveryHash=recoveryHash;return u;});
        return signIn(request,user,{recoveryCode:newCode});
      }
      // Derive a password even for missing accounts to avoid a cheap timing oracle.
      const encoded=existing?.passwordHash || `${'0'.repeat(32)}:600000:${'0'.repeat(64)}`;
      const derived=await derivePassword(password(body.password),encoded);
      assert(existing && safeEqual(derived,encoded.split(':')[2]),401,'账号或密码不正确');
      return signIn(request,existing);
    }
    if(method==='POST' && path==='/api/customer/logout') {
      const token=tokenOf(request);if(token)await db.prepare('DELETE FROM customer_sessions WHERE token_hash = ?').bind(await digest(token)).run();
      return reply({ok:true},200,{'Set-Cookie':cookie(request,'',0)});
    }
    const session=await auth(request);
    if(method==='GET' && path==='/api/customer/wallet')return reply(await mutate(state=>{
      const u=userIn(state,session);return {customer:summary(u),ledger:state.walletLedger.filter(l=>l.customerId===u.id),topups:state.topups.filter(t=>t.customerId===u.id).map(topupView)};
    }));
    if(method==='GET' && path==='/api/customer/orders')return reply(await mutate(state=>{const u=userIn(state,session);return {orders:state.orders.filter(o=>o.customerId===u.id).map(o=>publicOrder(o))};}));
    if(method==='POST' && path==='/api/customer/topups') {
      await limit(request,'topup-create',20,3600000);
      const body=await readJson(request,5000), amountCents=cents(body.amount), nonce=requestId(body.requestId), no='TOP'+now()+random(5);
      assert(['wechat','alipay'].includes(body.payMethod),400,'请选择充值付款方式');
      const topup=await mutate(state=>{
        const u=userIn(state,session), old=state.topups.find(t=>t.customerId===u.id && t.requestId===nonce);
        if(old){assert(old.amount===amountCents/100 && old.payMethod===body.payMethod,409,'重复请求内容不一致');return topupView(old);}
        assert(state.topups.filter(t=>t.customerId===u.id && ['pending','paid'].includes(t.status)).length<5,409,'你有5笔待处理充值，请先处理或关闭');
        const payment=paymentFor(state.settings,body.payMethod);assert(payment,400,'该充值方式暂不可用');
        const entry={topupNo:no,customerId:u.id,username:u.username,amount:amountCents/100,payMethod:body.payMethod,payment,status:'pending',createdAt:stamp(),requestId:nonce,payNote:''};state.topups.unshift(entry);return topupView(entry);
      });return reply({topup});
    }
    const match=path.match(/^\/api\/customer\/topups\/(TOP\d+[a-f0-9]+)\/(paid|cancel)$/);
    if(method==='POST' && match) {
      const body=await readJson(request,5000);
      return reply({topup:await mutate(state=>{
        const u=userIn(state,session),t=state.topups.find(x=>x.topupNo===match[1] && x.customerId===u.id);assert(t,404,'充值记录不存在');
        if(match[2]==='paid') {assert(['pending','paid'].includes(t.status),409,'充值状态已变化，请刷新钱包');if(t.status==='pending'){const note=String(body.payNote || '').trim();assert(note.length>=4 && note.length<=200,400,'请填写支付账单号或付款时间、付款方备注，便于核对');t.status='paid';t.paidAt=stamp();t.payNote=note;}}
        else {assert(['pending','closed'].includes(t.status),409,'已提交付款信息的充值请联系客服处理');t.status='closed';t.closeReason='客户取消';}
        return topupView(t);
      })});
    }
    assert(false,404,'接口不存在');
  }
  async function adminRoute(request,path,method,admin) {
    if(path==='/api/admin/wallet' && method==='GET')return reply(await protectedMutation(admin,state=>({customers:state.customers.map(summary),topups:state.topups.map(topupView),ledger:state.walletLedger})));
    const match=path.match(/^\/api\/admin\/topups\/(TOP\d+[a-f0-9]+)\/(confirm|cancel)$/);
    if(method!=='POST' || !match)return null;
    const body=await readJson(request,5000);
    return reply({topup:await protectedMutation(admin,state=>{
      const t=state.topups.find(x=>x.topupNo===match[1]);assert(t,404,'充值记录不存在');
      if(match[2]==='confirm') {
        if(t.status==='credited')return topupView(t);
        assert(t.status==='paid',409,'请等待客户提交付款信息，并核对实际到账');
        const reference=String(body.paymentReference || '').trim();assert(/^[a-zA-Z0-9_-]{6,100}$/.test(reference),400,'请填写收款平台的真实交易单号（6–100位字母或数字）');
        assert(!state.topups.some(x=>x.payMethod===t.payMethod && x.paymentReference===reference && x.status==='credited'),409,'此收款交易单号已用于另一笔充值，请勿重复入账');
        const u=state.customers.find(x=>x.id===t.customerId);assert(u,409,'客户账户不存在');
        move(state,u,'topup',Math.round(t.amount*100),t.topupNo,'充值到账');t.status='credited';t.creditedAt=stamp();t.paymentReference=reference;
      } else {
        assert(t.status!=='credited',409,'已入账充值不能关闭');
        t.status='closed';t.closeReason=String(body.reason || '商家未核实到款，请联系客服').slice(0,200);
      }
      return topupView(t);
    })});
  }
  return {publicRoute,adminRoute,auth,userIn,summary,spend,refund,csrf,requestId};
}
