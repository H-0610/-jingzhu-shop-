import test from 'node:test';
import assert from 'node:assert/strict';
import { PGlite } from '@electric-sql/pglite';
import { initializePostgres, postgresAdapter, postgresConfig } from './postgres.mjs';
import { startShop } from './server.mjs';
import { importPostgresBackup, exportPostgresBackup } from './tools/postgres-backup.mjs';

test('PostgreSQL binds customer text safely, uses millisecond timestamps, and preserves atomic version updates', async t => {
  const pg = new PGlite(); t.after(() => pg.close());
  await initializePostgres(sql => pg.query(sql));
  const db = postgresAdapter((sql, values) => pg.query(sql, values));
  const text = "中文 ' ? ; DROP TABLE shop_state; --";
  await db.prepare('INSERT OR IGNORE INTO shop_state (id,data,version) VALUES (1,?,0)').bind(text).run();
  await db.prepare('INSERT OR IGNORE INTO shop_state (id,data,version) VALUES (1,?,0)').bind('duplicate').run();
  assert.equal(await db.prepare('SELECT data FROM shop_state WHERE id=1').first('data'), text);
  const attempts = await Promise.all(['winner-a','winner-b'].map(value => db.prepare('UPDATE shop_state SET data=?,version=version+1 WHERE id=1 AND version=?').bind(value,0).run()));
  assert.equal(attempts.filter(r => r.meta.changes === 1).length, 1);
  const stamp = Date.now() + 43200000;
  await db.prepare('INSERT INTO admin_sessions(token_hash,expires_at) VALUES(?,?)').bind('test',stamp).run();
  assert.equal(Number(await db.prepare('SELECT expires_at FROM admin_sessions WHERE token_hash=?').bind('test').first('expires_at')),stamp);
});

test('cloud configuration enforces external storage and verified TLS', async () => {
  await assert.rejects(startShop({requirePostgres:true,databaseUrl:'',port:0}),/必须配置DATABASE_URL/);
  const config = postgresConfig('postgresql://test:test@example.test/db?sslmode=disable');
  assert.equal(config.ssl.rejectUnauthorized,true);
  assert.equal(new URL(config.connectionString).searchParams.has('sslmode'),false);
});

test('platform health checks do not query the database or consume idle compute', async t => {
  const pg = new PGlite(); let reads = 0;
  await initializePostgres(sql => pg.query(sql));
  const db = postgresAdapter((sql, values) => { reads++; return pg.query(sql, values); }, () => pg.close());
  const service = await startShop({port:0,database:db,password:'health-test-password-2026',seed:{settings:{shopName:'test'},products:[],orders:[]}});
  t.after(() => service.close()); const baseline=reads;
  for(let i=0;i<3;i++)assert.equal((await fetch(`http://127.0.0.1:${service.port}/healthz`)).status,200);
  assert.equal(reads,baseline);
});

test('PostgreSQL migration preserves private order keys and images, rejects overwrite, and rolls back partial imports',async t=>{
  const pg=new PGlite();t.after(()=>pg.close());await initializePostgres(sql=>pg.query(sql));
  const db={transaction:fn=>pg.transaction(tx=>fn((sql,args)=>tx.query(sql,args)))};
  const image={id:'a'.repeat(32),mime:'image/png',data:'aGVsbG8=',created_at:Date.now()};
  const input={state:{settings:{adminPasswordHash:'b'.repeat(32)+':100000:'+'c'.repeat(64),shareImage:'/api/assets/'+image.id},products:[],orders:[{orderKeyHash:'d'.repeat(64),reservedContent:'private-content'}]},assets:[image]};
  await assert.rejects(importPostgresBackup(db,{...input,assets:[image,image]}));
  assert.equal((await pg.query('SELECT count(*)::int AS n FROM shop_state')).rows[0].n,0);
  assert.deepEqual(await importPostgresBackup(db,input),{products:0,orders:1,assets:1});
  await assert.rejects(importPostgresBackup(db,input),/非空/);
  const backup=await exportPostgresBackup(db);assert.deepEqual(backup.state,input.state);assert.equal(backup.assets[0].data,image.data);
});
