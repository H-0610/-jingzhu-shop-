import { Pool } from 'pg';
import { readFile } from 'node:fs/promises';

// The core uses D1-style bound parameters. Only SQL authored by the app is translated;
// user data is always passed separately to the PostgreSQL driver.
export function postgresSql(sql) {
  let index = 0;
  let converted = sql.replace(/'(?:''|[^'])*'|"(?:""|[^"])*"|\?/g, token => token === '?' ? `$${++index}` : token);
  if (/^INSERT OR IGNORE INTO /i.test(converted)) {
    converted = converted.replace(/^INSERT OR IGNORE INTO /i, 'INSERT INTO ').replace(/;?$/, ' ON CONFLICT DO NOTHING');
  }
  return converted;
}

export function postgresAdapter(query, close = async () => {}) {
  const prepare = (sql, values = []) => ({
    bind(...parameters) { return prepare(sql, parameters); },
    async first(column) {
      const row = (await query(postgresSql(sql), values)).rows[0] || null;
      return column && row ? row[column] : row;
    },
    async all() { return { success: true, results: (await query(postgresSql(sql), values)).rows }; },
    async run() {
      const result = await query(postgresSql(sql), values);
      return { success: true, meta: { changes: Number(result.rowCount ?? result.affectedRows ?? 0) } };
    },
  });
  return { prepare, close };
}

export async function initializePostgres(query) {
  const schema = await readFile(new URL('./schema-postgres.sql', import.meta.url), 'utf8');
  // Separate statements also work with PostgreSQL clients using the extended protocol.
  for (const statement of schema.split(';').map(s => s.trim()).filter(Boolean)) await query(statement);
}

export function postgresConfig(connectionString) {
  let url;
  try { url = new URL(connectionString); } catch { throw new Error('DATABASE_URL格式不正确'); }
  if (!['postgres:', 'postgresql:'].includes(url.protocol)) throw new Error('DATABASE_URL必须为PostgreSQL连接地址');
  // Enforce certificate and hostname validation regardless of provider URL defaults.
  for (const name of ['sslmode', 'sslcert', 'sslkey', 'sslrootcert', 'uselibpqcompat']) url.searchParams.delete(name);
  return { connectionString: url.href, ssl: { rejectUnauthorized: true }, max: 3,
    idleTimeoutMillis: 10000, connectionTimeoutMillis: 20000, statement_timeout: 15000,
    application_name: 'jingzhu-shop' };
}

export async function openPostgres(connectionString) {
  const pool = new Pool(postgresConfig(connectionString));
  pool.on('error', () => console.error('Database connection unavailable'));
  try {
    const migrationUrl = new URL(connectionString);
    if (migrationUrl.hostname.endsWith('.neon.tech') && migrationUrl.hostname.includes('-pooler.')) {
      migrationUrl.hostname = migrationUrl.hostname.replace('-pooler.', '.');
      const migrationPool = new Pool(postgresConfig(migrationUrl.href));
      try { await initializePostgres(sql => migrationPool.query(sql)); }
      finally { await migrationPool.end(); }
    } else await initializePostgres(sql => pool.query(sql));
    const db = postgresAdapter((sql, values) => pool.query(sql, values), () => pool.end());
    db.transaction = async operation => {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const result = await operation((sql, values) => client.query(sql, values));
        await client.query('COMMIT');
        return result;
      } catch (error) { await client.query('ROLLBACK'); throw error; }
      finally { client.release(); }
    };
    return db;
  } catch (error) { await pool.end(); throw error; }
}
