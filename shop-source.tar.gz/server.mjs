import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { isIP } from 'node:net';
import { openDatabase } from './database.mjs';
import { createShopApi } from './server/core.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const PUBLIC=path.join(ROOT,'public');
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SECURITY={
  'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store'
};
const MIME={'.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.ico':'image/x-icon','.txt':'text/plain; charset=utf-8'};
export function clientIp(request,hops=0){
  const peer=request.socket.remoteAddress||'unknown';
  if(!hops)return peer;
  const header=request.headers['x-forwarded-for'];
  const chain=[...(typeof header==='string'?header.split(',').map(v=>v.trim()):[]),peer];
  if(chain.length<=hops)return peer;
  const candidate=chain[chain.length-1-hops];
  return isIP(candidate)?candidate:peer;
}
function makeCredential(password){
  if(typeof password!=='string'||password.length<12||password.length>128)throw new Error('首次启动需配置12至128位 INITIAL_ADMIN_PASSWORD，或导入含有效管理员凭据的完整状态。');
  const salt=randomBytes(16);return `${salt.toString('hex')}:100000:${pbkdf2Sync(password,salt,100000,32,'sha256').toString('hex')}`;
}
export async function startShop({port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1',filename=process.env.DATABASE_PATH||path.join(ROOT,'data/shop.sqlite'),origin=process.env.PUBLIC_BASE_URL||process.env.RENDER_EXTERNAL_URL||`http://127.0.0.1:${port}`,password=process.env.INITIAL_ADMIN_PASSWORD,credential=process.env.ADMIN_INITIAL_PASSWORD_HASH||'',proxyHops=Number(process.env.TRUST_PROXY_HOPS||0),seed}={}){
  if(!Number.isInteger(proxyHops)||proxyHops<0||proxyHops>5)throw new Error('TRUST_PROXY_HOPS必须为0至5的整数');
  const base=new URL(origin);
  if(!['http:','https:'].includes(base.protocol)||base.username||base.password)throw new Error('PUBLIC_BASE_URL格式不正确');
  const db=openDatabase(filename);
  try {
    const row=db.sqlite.prepare('SELECT data FROM shop_state WHERE id=1').get();
    const existingHash=row?JSON.parse(row.data)?.settings?.adminPasswordHash:'';
    const validHash=v=>/^[a-f0-9]{32,128}:\d{5,6}:[a-f0-9]{64}$/i.test(v||'');
    if(row&&!validHash(existingHash))throw new Error('导入数据缺少有效管理员凭据，请完成离线迁移配置');
    if(!row&&!validHash(credential))credential=makeCredential(password);
    const initial=seed||JSON.parse(await fs.readFile(path.join(ROOT,'server/seed.json'),'utf8'));
    const api=createShopApi({db,seed:initial,initialPasswordHash:credential});
    await api.getPublicSettings();
    const templates={shop:await fs.readFile(path.join(ROOT,'server/templates/index.html'),'utf8'),admin:await fs.readFile(path.join(ROOT,'server/templates/admin.html'),'utf8')};
    const server=http.createServer(async(req,res)=>{
      let requestPath='';
      try {
        const url=new URL(req.url,base.origin);requestPath=url.pathname;
        let response;
        if(requestPath==='/healthz'){
          db.sqlite.prepare('SELECT version FROM shop_state WHERE id=1').get();
          response=Response.json({ok:true},{headers:SECURITY});
        }else if(requestPath.startsWith('/api/')){
          let chunks=[],length=0;
          for await(const chunk of req){length+=chunk.length;if(length>3_000_000){response=Response.json({error:'请求内容过大'},{status:413});break;}chunks.push(chunk);}
          if(!response){
            const headers=new Headers();
            for(const key of ['content-type','authorization','x-order-key'])if(typeof req.headers[key]==='string')headers.set(key,req.headers[key]);
            // Never trust arbitrary CF identity/IP headers outside the original platform.
            headers.set('cf-connecting-ip',clientIp(req,proxyHops));
            const body=length?Buffer.concat(chunks):undefined;
            response=await api.handle(new Request(url,{method:req.method,headers,body:['GET','HEAD'].includes(req.method)?undefined:body}));
          }
        }else if(['GET','HEAD'].includes(req.method)&&(requestPath==='/'||requestPath==='/admin'||requestPath==='/admin/')){
          let html=templates.admin;
          if(requestPath==='/'){
            const s=await api.getPublicSettings();
            const title=escape(s.shopName||'景筑小铺'),desc=escape(s.shareDesc||'自助选购，扫码付款，随时查询订单');
            const image=escape(new URL(s.shareImage||'/share-card.png',base.origin).href);
            html=templates.shop.replace('<title>小铺</title>',`<title>${title}</title><meta name="description" content="${desc}"/><meta property="og:title" content="${title}"/><meta property="og:description" content="${desc}"/><meta property="og:image" content="${image}"/><meta property="og:url" content="${escape(base.origin)}/"/>`);
          }
          response=new Response(html,{headers:{...SECURITY,'Content-Type':'text/html; charset=utf-8',...(requestPath.startsWith('/admin')?{'X-Robots-Tag':'noindex, nofollow'}:{})}});
        }else if(['GET','HEAD'].includes(req.method)){
          let decoded;
          try{decoded=decodeURIComponent(requestPath);}catch{decoded='';}
          const destination=path.resolve(PUBLIC,'.'+decoded);
          if(!decoded||decoded.includes('\0')||decoded.includes('\\')||!destination.startsWith(PUBLIC+path.sep))response=new Response('Not found',{status:404});
          else{
            try{
              const real=await fs.realpath(destination);
              if(!real.startsWith(PUBLIC+path.sep))throw new Error('Invalid asset');
              const mime=MIME[path.extname(real).toLowerCase()];
              if(!mime)throw new Error('Unsupported asset');
              response=new Response(await fs.readFile(real),{headers:{...SECURITY,'Content-Type':mime}});
            }catch{response=new Response('Not found',{status:404});}
          }
        }else response=new Response('Method not allowed',{status:405});
        res.writeHead(response.status,{...SECURITY,...Object.fromEntries(response.headers)});
        res.end(req.method==='HEAD'?undefined:Buffer.from(await response.arrayBuffer()));
      }catch(error){
        console.error('Request failed',req.method,requestPath,error.name);
        if(!res.headersSent)res.writeHead(503,{...SECURITY,'Content-Type':'application/json; charset=utf-8'});
        res.end(JSON.stringify({error:'店铺服务暂时不可用，请稍后重试'}));
      }
    });
    server.requestTimeout=30000;server.headersTimeout=15000;
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});
    return {server,db,port:server.address().port,async close(){await new Promise(resolve=>server.close(resolve));db.close();}};
  }catch(error){db.close();throw error;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{
    const service=await startShop();console.log(`Shop listening on port ${service.port}`);
    for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{service.close().then(()=>process.exit(0));setTimeout(()=>process.exit(1),10000).unref();});
  }catch(error){console.error(error.message);process.exitCode=1;}
}
