import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
export function openDatabase(filename) {
  if(filename!==':memory:')mkdirSync(dirname(filename),{recursive:true});
  const sqlite=new DatabaseSync(filename);
  sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  sqlite.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
  const prepare=(sql,parameters=[])=>({
    bind(...values){return prepare(sql,values);},
    async first(column){const row=sqlite.prepare(sql).get(...parameters)||null;return column&&row?row[column]:row;},
    async all(){return {success:true,results:sqlite.prepare(sql).all(...parameters)};},
    async run(){const r=sqlite.prepare(sql).run(...parameters);return {success:true,meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};}
  });
  return {sqlite,prepare,close(){sqlite.close();}};
}
